@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

call :find_python
if not defined PYTHON_EXE goto :no_python

echo Using Python:
echo   !PYTHON_EXE!
echo.
"!PYTHON_EXE!" app.py
exit /b %errorlevel%

:find_python
set "PYTHON_EXE="
where py >nul 2>nul
if not errorlevel 1 (
  for /f "usebackq delims=" %%I in (`py -3 -c "import sys; print(sys.executable)" 2^>nul`) do set "PYTHON_EXE=%%I"
  if defined PYTHON_EXE goto :eof
)
for /f "delims=" %%I in ('where python 2^>nul') do (
  echo %%~fI | find /i "WindowsApps" >nul
  if errorlevel 1 (
    set "PYTHON_EXE=%%~fI"
    goto :eof
  )
)
for %%R in ("%LocalAppData%\Programs\Python" "%ProgramFiles%\Python" "%ProgramFiles(x86)%\Python") do (
  if exist "%%~R" (
    for /f "delims=" %%I in ('dir /b /ad /o-n "%%~R\Python*" 2^>nul') do (
      if exist "%%~R\%%~I\python.exe" (
        set "PYTHON_EXE=%%~R\%%~I\python.exe"
        goto :eof
      )
    )
  )
)
goto :eof

:no_python
echo Could not find a usable Python installation.
echo Install Python from python.org and tick ^"Add Python to PATH^", or turn off the
ECHO Microsoft Store app execution aliases for python.exe / python3.exe.
pause
exit /b 1
