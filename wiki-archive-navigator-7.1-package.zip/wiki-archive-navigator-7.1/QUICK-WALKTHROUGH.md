# Quick Walkthrough

## Best first step

Start with **Search & Save Pages** unless you truly want a whole wiki archive.

## Search & Save Pages

1. Choose a Wikimedia project and language.
2. Open **Search & Save Pages**.
3. Search the wiki.
4. Double-click a result to open it as a local webpage, or add the result to the save list.
5. Click **Save save list as local archive** when your save list is ready.

## Download Entire Wiki

1. Choose a Wikimedia project and language.
2. Open **Download Entire Wiki**.
3. Click **1. Load archive dates**.
4. Highlight a date.
5. Click **2. Show whole-archive choices**.
6. Highlight a choice.
7. Read the review panel.
8. Tick the confirmation box.
9. Click **4. Start whole-archive download**.
10. Confirm the final dialog.

## Browse an archive locally

1. Open or import an archive into **Archive Library**.
2. Double-click the archive, or click **Load highlighted archive pages**.
3. Use the **Page filter** if the archive is large.
4. Double-click a page row to open it as a local wiki-style webpage.

## Check for updates

1. Highlight a library archive.
2. Click **Check for updates**.
3. Full dump archives check for newer dump dates.
4. Saved page bundles check live wiki edits.

## Easy rule of thumb

- Want the **whole wiki**? Use **Download Entire Wiki**.
- Want **just a few pages**? Use **Search & Save Pages**.
