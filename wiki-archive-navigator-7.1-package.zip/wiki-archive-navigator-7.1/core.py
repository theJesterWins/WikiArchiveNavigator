from __future__ import annotations

import bz2
import gzip
import hashlib
import html
import json
import os
import re
import shutil
import traceback
import urllib.error
import urllib.parse
import urllib.request
import uuid
import xml.etree.ElementTree as ET
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Optional

APP_NAME = "Wiki Archive Navigator"
APP_VERSION = "7.0.0"
APP_HOME = Path.home() / ".wiki_archive_navigator"
ARCHIVE_HOME = APP_HOME / "archives"
CACHE_HOME = APP_HOME / "page_cache"
PREVIEW_HOME = APP_HOME / "web_preview"
STATE_PATH = APP_HOME / "state.json"

APP_HOME.mkdir(parents=True, exist_ok=True)
ARCHIVE_HOME.mkdir(parents=True, exist_ok=True)
CACHE_HOME.mkdir(parents=True, exist_ok=True)
PREVIEW_HOME.mkdir(parents=True, exist_ok=True)

USER_AGENT = (
    f"{APP_NAME}/{APP_VERSION} "
    "(Independent Wikimedia archive browser; not affiliated with the Wikimedia Foundation)"
)

XML_NS_URI = "http://www.mediawiki.org/xml/export-0.11/"
XSI_NS_URI = "http://www.w3.org/2001/XMLSchema-instance"
XML_SPACE_NS = "http://www.w3.org/XML/1998/namespace"
ET.register_namespace("", XML_NS_URI)
ET.register_namespace("xsi", XSI_NS_URI)

WIKILINK_PATTERN = re.compile(r"\[\[([^\[\]]+?)\]\]")
TEMPLATE_PATTERN = re.compile(r"\{\{[^{}]*\}\}")
COMMENT_PATTERN = re.compile(r"<!--.*?-->", re.S)
REF_PATTERN = re.compile(r"<ref[^>]*>.*?</ref>", re.I | re.S)
HTML_TAG_PATTERN = re.compile(r"<[^>]+>")
MULTISPACE_PATTERN = re.compile(r"[ 	]+")
MULTINEWLINE_PATTERN = re.compile(r"\n{3,}")
DIRECTORY_ENTRY_PATTERN = re.compile(
    r'<a href="(?P<href>[^"]+)">(?P<label>[^<]+)</a>\s*(?P<date>\d{2}-[A-Za-z]{3}-\d{4}\s+\d{2}:\d{2})\s+(?P<size>[0-9-]+)',
    re.I,
)
DUMP_DATE_PATTERN = re.compile(r"^\d{8}/$")
DUMP_PART_PATTERN = re.compile(r"(?:current|history|articles|multistream)\d+\.xml-p\d+p\d+", re.I)

FIXED_PROJECTS: dict[str, str] = {
    "Abstract Wikipedia": "https://abstract.wikipedia.org/w/api.php",
    "Wikidata": "https://www.wikidata.org/w/api.php",
    "Wikifunctions": "https://www.wikifunctions.org/w/api.php",
    "Wikimedia Commons": "https://commons.wikimedia.org/w/api.php",
    "Meta-Wiki": "https://meta.wikimedia.org/w/api.php",
    "MediaWiki": "https://www.mediawiki.org/w/api.php",
    "Wikimedia Incubator": "https://incubator.wikimedia.org/w/api.php",
    "Wikispecies": "https://species.wikimedia.org/w/api.php",
}

LANGUAGE_PROJECTS: dict[str, str] = {
    "Wikipedia": "wikipedia.org",
    "Wiktionary": "wiktionary.org",
    "Wikibooks": "wikibooks.org",
    "Wikiquote": "wikiquote.org",
    "Wikisource": "wikisource.org",
    "Wikinews": "wikinews.org",
    "Wikiversity": "wikiversity.org",
    "Wikivoyage": "wikivoyage.org",
}

DUMP_CHOICES: dict[str, str] = {
    "recommended_reading": "Recommended reading archive",
    "all_pages_current": "Entire wiki — current revision",
    "full_history": "Entire wiki — full history",
}


class WikiArchiveError(RuntimeError):
    """Raised for user-visible archive and API issues."""


@dataclass
class RevisionRecord:
    revision_id: str = ""
    parent_id: str = ""
    timestamp: str = ""
    contributor: str = ""
    comment: str = ""
    model: str = ""
    format_name: str = ""
    sha1: str = ""
    bytes_count: int = 0
    text: str = ""


@dataclass
class PageRecord:
    title: str = ""
    namespace: int = 0
    page_id: str = ""
    revisions: list[RevisionRecord] = field(default_factory=list)

    @property
    def latest_revision(self) -> Optional[RevisionRecord]:
        return self.revisions[-1] if self.revisions else None

    @property
    def latest_timestamp(self) -> str:
        return self.latest_revision.timestamp if self.latest_revision else ""


@dataclass
class PageIndexEntry:
    title: str
    namespace: int
    page_id: str
    latest_timestamp: str
    revision_count: int


@dataclass
class SiteInfo:
    sitename: str = ""
    dbname: str = ""
    base: str = ""
    generator: str = ""
    case: str = "first-letter"
    lang: str = "en"
    namespaces: dict[int, str] = field(default_factory=dict)
    api_url: str = ""


@dataclass
class LoadedArchive:
    title: str
    source_label: str
    source_path: str
    siteinfo: SiteInfo
    page_index: list[PageIndexEntry]
    pages: dict[str, PageRecord] = field(default_factory=dict)


@dataclass
class SearchResult:
    title: str
    namespace: int
    namespace_label: str
    page_id: str
    latest_timestamp: str
    snippet: str
    api_url: str
    site_label: str
    downloaded: bool = False
    downloaded_at: str = ""


@dataclass
class QueueItem:
    title: str
    namespace: int
    namespace_label: str
    page_id: str
    latest_timestamp: str
    api_url: str
    site_label: str
    downloaded: bool = False
    downloaded_at: str = ""


@dataclass
class DumpRun:
    dbname: str
    run: str
    listed_at: str
    url: str
    is_latest: bool = False
    downloaded: bool = False

    @property
    def display_name(self) -> str:
        if self.run == "latest":
            return "latest"
        return format_dump_run(self.run)


@dataclass
class DumpFile:
    dbname: str
    run: str
    filename: str
    url: str
    uploaded_at: str
    size_text: str
    family: str
    family_label: str
    supported: bool
    recommended: bool = False
    downloaded: bool = False

    @property
    def size_bytes(self) -> Optional[int]:
        return int(self.size_text) if self.size_text.isdigit() else None


@dataclass
class DumpOption:
    option_id: str
    dbname: str
    run: str
    title: str
    scope_label: str
    type_label: str
    uploaded_at: str
    total_size_text: str
    file_count: int
    files: list[DumpFile] = field(default_factory=list)
    recommended: bool = False
    downloaded: bool = False
    note: str = ""


@dataclass
class BundleEntry:
    entry_id: str
    name: str
    path: str
    bundle_type: str
    source_kind: str
    site_name: str
    api_url: str
    base_url: str
    dbname: str
    page_count: int
    revision_count: int
    pages: list[PageIndexEntry]
    added_at: str
    last_opened_at: str = ""
    last_checked_at: str = ""
    update_count: int = 0
    managed_copy: bool = False
    fingerprint: str = ""
    site_lang: str = "en"
    site_case: str = "first-letter"
    site_generator: str = ""
    site_namespaces: dict[int, str] = field(default_factory=dict)
    remote_source_url: str = ""
    dump_dbname: str = ""
    dump_run: str = ""
    dump_filename: str = ""
    source_files: list[str] = field(default_factory=list)
    dump_filenames: list[str] = field(default_factory=list)

    def to_state(self) -> dict[str, Any]:
        data = asdict(self)
        data["pages"] = [asdict(page) for page in self.pages]
        data["site_namespaces"] = {str(key): value for key, value in self.site_namespaces.items()}
        return data

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "BundleEntry":
        pages = [PageIndexEntry(**page) for page in data.get("pages", [])]
        raw_namespaces = data.get("site_namespaces", {})
        site_namespaces = {int(key): value for key, value in raw_namespaces.items()} if isinstance(raw_namespaces, dict) else {}
        return cls(
            entry_id=data["entry_id"],
            name=data.get("name", ""),
            path=data.get("path", ""),
            bundle_type=data.get("bundle_type", "xml"),
            source_kind=data.get("source_kind", "imported"),
            site_name=data.get("site_name", ""),
            api_url=data.get("api_url", ""),
            base_url=data.get("base_url", ""),
            dbname=data.get("dbname", ""),
            page_count=int(data.get("page_count", 0)),
            revision_count=int(data.get("revision_count", 0)),
            pages=pages,
            added_at=data.get("added_at", ""),
            last_opened_at=data.get("last_opened_at", ""),
            last_checked_at=data.get("last_checked_at", ""),
            update_count=int(data.get("update_count", 0)),
            managed_copy=bool(data.get("managed_copy", False)),
            fingerprint=data.get("fingerprint", ""),
            site_lang=data.get("site_lang", "en"),
            site_case=data.get("site_case", "first-letter"),
            site_generator=data.get("site_generator", ""),
            site_namespaces=site_namespaces,
            remote_source_url=data.get("remote_source_url", ""),
            dump_dbname=data.get("dump_dbname", ""),
            dump_run=data.get("dump_run", ""),
            dump_filename=data.get("dump_filename", ""),
            source_files=list(data.get("source_files", []) or []),
            dump_filenames=list(data.get("dump_filenames", []) or []),
        )


def now_utc_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def safe_local_time(iso_text: str) -> str:
    if not iso_text:
        return ""
    try:
        normalized = iso_text.replace("Z", "+00:00")
        dt = datetime.fromisoformat(normalized)
        return dt.astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")
    except Exception:
        return iso_text


def safe_display_date(iso_text: str) -> str:
    local = safe_local_time(iso_text)
    if not local:
        return ""
    if len(local) > 19:
        return local[:19]
    return local


def ns_tag(local_name: str) -> str:
    return f"{{{XML_NS_URI}}}{local_name}"


def ensure_directory(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def atomic_write_json(path: Path, data: dict[str, Any]) -> None:
    temp_path = path.with_suffix(path.suffix + ".tmp")
    temp_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    temp_path.replace(path)


class StateStore:
    def __init__(self, state_path: Path = STATE_PATH) -> None:
        self.state_path = state_path
        self.state: dict[str, Any] = self._load_state()

    def _blank_state(self) -> dict[str, Any]:
        return {
            "settings": {
                "archive_folder": str(ARCHIVE_HOME),
                "window_geometry": "1440x900",
                "project_name": "Abstract Wikipedia",
                "language_code": "en",
                "save_format": "MediaWiki XML (.xml)",
                "dump_choice": DUMP_CHOICES["recommended_reading"],
            },
            "bundles": [],
        }

    def _load_state(self) -> dict[str, Any]:
        if not self.state_path.exists():
            return self._blank_state()
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
        except Exception:
            backup = self.state_path.with_suffix(".corrupt.json")
            shutil.copy2(self.state_path, backup)
            return self._blank_state()
        data.setdefault("settings", {})
        data.setdefault("bundles", [])
        defaults = self._blank_state()["settings"]
        for key, value in defaults.items():
            data["settings"].setdefault(key, value)
        return data

    def save(self) -> None:
        atomic_write_json(self.state_path, self.state)

    def get_setting(self, key: str, default: Any = None) -> Any:
        return self.state.setdefault("settings", {}).get(key, default)

    def set_setting(self, key: str, value: Any) -> None:
        self.state.setdefault("settings", {})[key] = value

    def archive_folder(self) -> Path:
        folder = Path(self.get_setting("archive_folder", str(ARCHIVE_HOME)))
        ensure_directory(folder)
        return folder

    def bundle_entries(self) -> list[BundleEntry]:
        return [BundleEntry.from_state(item) for item in self.state.get("bundles", [])]

    def upsert_bundle(self, entry: BundleEntry) -> None:
        bundles = self.state.setdefault("bundles", [])
        for index, existing in enumerate(bundles):
            if existing.get("entry_id") == entry.entry_id:
                bundles[index] = entry.to_state()
                break
        else:
            bundles.append(entry.to_state())
        self.save()

    def remove_bundle(self, entry_id: str) -> None:
        bundles = self.state.setdefault("bundles", [])
        self.state["bundles"] = [item for item in bundles if item.get("entry_id") != entry_id]
        self.save()

    def bundle_by_path(self, path: str) -> Optional[BundleEntry]:
        normalized = os.path.normcase(os.path.abspath(path))
        for bundle in self.bundle_entries():
            if os.path.normcase(os.path.abspath(bundle.path)) == normalized:
                return bundle
        return None

    def download_index(self) -> dict[tuple[str, str], dict[str, str]]:
        index: dict[tuple[str, str], dict[str, str]] = {}
        for bundle in self.bundle_entries():
            if bundle.source_kind == "full_dump":
                continue
            for page in bundle.pages:
                key = download_key(bundle.api_url, page.title)
                existing = index.get(key)
                if existing is None or bundle.added_at > existing.get("downloaded_at", ""):
                    index[key] = {
                        "downloaded_at": bundle.added_at,
                        "bundle_id": bundle.entry_id,
                        "bundle_name": bundle.name,
                    }
        return index

    def dump_download_index(self) -> dict[tuple[str, str, str], dict[str, str]]:
        index: dict[tuple[str, str, str], dict[str, str]] = {}
        for bundle in self.bundle_entries():
            if not bundle.dump_dbname or not bundle.dump_run:
                continue
            filenames = list(bundle.dump_filenames or [])
            if not filenames and bundle.dump_filename:
                filenames = [bundle.dump_filename]
            for filename in filenames:
                index[(bundle.dump_dbname, bundle.dump_run, filename)] = {
                    "bundle_id": bundle.entry_id,
                    "bundle_name": bundle.name,
                    "downloaded_at": bundle.added_at,
                }
        return index


class WikiApiClient:
    def __init__(self, logger: Optional[Callable[[str], None]] = None) -> None:
        self.siteinfo_cache: dict[str, SiteInfo] = {}
        self.logger = logger or (lambda message: None)

    def _request_json(self, api_url: str, params: dict[str, Any]) -> dict[str, Any]:
        query_params = {key: value for key, value in params.items() if value not in (None, "")}
        query_params.setdefault("format", "json")
        query_params.setdefault("formatversion", 2)
        encoded = urllib.parse.urlencode(query_params, doseq=True)
        request = urllib.request.Request(
            f"{api_url}?{encoded}",
            headers={
                "User-Agent": USER_AGENT,
                "Accept": "application/json",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            try:
                detail = exc.read().decode("utf-8", errors="replace")
            except Exception:
                detail = str(exc)
            raise WikiArchiveError(f"Wiki request failed with HTTP {exc.code}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise WikiArchiveError(f"Wiki request failed: {exc.reason}") from exc
        except Exception as exc:
            raise WikiArchiveError(f"Wiki request failed: {exc}") from exc
        try:
            payload = json.loads(raw.decode("utf-8"))
        except Exception as exc:
            raise WikiArchiveError(f"Wiki response was not valid JSON: {exc}") from exc
        if isinstance(payload, dict) and payload.get("error"):
            error = payload["error"]
            raise WikiArchiveError(error.get("info") or error.get("code") or "Wiki API returned an error.")
        return payload

    def get_siteinfo(self, api_url: str) -> SiteInfo:
        if api_url in self.siteinfo_cache:
            return self.siteinfo_cache[api_url]
        payload = self._request_json(
            api_url,
            {
                "action": "query",
                "meta": "siteinfo",
                "siprop": "general|namespaces",
            },
        )
        general = payload.get("query", {}).get("general", {})
        namespaces_data = payload.get("query", {}).get("namespaces", {})
        namespaces: dict[int, str] = {}
        if isinstance(namespaces_data, list):
            for item in namespaces_data:
                try:
                    ns_id = int(item.get("id", item.get("key", 0)))
                except Exception:
                    continue
                namespaces[ns_id] = item.get("name") or item.get("*") or ""
        elif isinstance(namespaces_data, dict):
            for key, item in namespaces_data.items():
                try:
                    ns_id = int(key)
                except Exception:
                    continue
                if isinstance(item, dict):
                    namespaces[ns_id] = item.get("name") or item.get("*") or ""
                else:
                    namespaces[ns_id] = str(item)
        siteinfo = SiteInfo(
            sitename=general.get("sitename", ""),
            dbname=general.get("wikiid", "") or general.get("dbname", ""),
            base=general.get("base", ""),
            generator=general.get("generator", ""),
            case=general.get("case", "first-letter"),
            lang=general.get("lang", "en"),
            namespaces=namespaces,
            api_url=api_url,
        )
        self.siteinfo_cache[api_url] = siteinfo
        return siteinfo

    def search_pages(self, api_url: str, search_text: str, limit: int = 50) -> list[SearchResult]:
        siteinfo = self.get_siteinfo(api_url)
        payload = self._request_json(
            api_url,
            {
                "action": "query",
                "list": "search",
                "srsearch": search_text,
                "srlimit": min(max(limit, 1), 50),
                "srprop": "snippet|timestamp",
            },
        )
        results: list[SearchResult] = []
        for item in payload.get("query", {}).get("search", []):
            namespace = int(item.get("ns", 0))
            snippet = strip_html(item.get("snippet", ""))
            results.append(
                SearchResult(
                    title=item.get("title", ""),
                    namespace=namespace,
                    namespace_label=namespace_label(namespace, siteinfo.namespaces),
                    page_id=str(item.get("pageid", "")),
                    latest_timestamp=item.get("timestamp", ""),
                    snippet=snippet,
                    api_url=api_url,
                    site_label=siteinfo.sitename or api_url,
                )
            )
        return results

    def get_page_links(self, api_url: str, title: str) -> list[QueueItem]:
        siteinfo = self.get_siteinfo(api_url)
        continue_token: Optional[str] = None
        items: list[QueueItem] = []
        seen: set[str] = set()
        while True:
            params: dict[str, Any] = {
                "action": "query",
                "prop": "links",
                "titles": title,
                "pllimit": "max",
            }
            if continue_token:
                params["plcontinue"] = continue_token
            payload = self._request_json(api_url, params)
            pages = payload.get("query", {}).get("pages", [])
            if pages:
                page = pages[0]
                for link in page.get("links", []):
                    link_title = link.get("title", "")
                    if not link_title:
                        continue
                    key = normalize_title(link_title)
                    if key in seen:
                        continue
                    seen.add(key)
                    namespace = int(link.get("ns", 0))
                    items.append(
                        QueueItem(
                            title=link_title,
                            namespace=namespace,
                            namespace_label=namespace_label(namespace, siteinfo.namespaces),
                            page_id="",
                            latest_timestamp="",
                            api_url=api_url,
                            site_label=siteinfo.sitename or api_url,
                        )
                    )
            continuation = payload.get("continue", {})
            continue_token = continuation.get("plcontinue")
            if not continue_token:
                break
        return items

    def fetch_latest_page(self, api_url: str, title: str) -> tuple[SiteInfo, PageRecord]:
        return self._fetch_page(api_url, title, latest_only=True)

    def fetch_full_page_history(self, api_url: str, title: str) -> tuple[SiteInfo, PageRecord]:
        return self._fetch_page(api_url, title, latest_only=False)

    def _fetch_page(self, api_url: str, title: str, latest_only: bool) -> tuple[SiteInfo, PageRecord]:
        siteinfo = self.get_siteinfo(api_url)
        continue_token: Optional[str] = None
        page_record: Optional[PageRecord] = None
        while True:
            params: dict[str, Any] = {
                "action": "query",
                "prop": "info|revisions",
                "inprop": "url",
                "titles": title,
                "redirects": 1,
                "rvprop": "ids|timestamp|user|comment|contentmodel|contentformat|sha1|size|content",
                "rvslots": "main",
                "rvlimit": 1 if latest_only else "max",
            }
            if continue_token:
                params["rvcontinue"] = continue_token
            payload = self._request_json(api_url, params)
            pages = payload.get("query", {}).get("pages", [])
            if not pages:
                raise WikiArchiveError(f"No page data was returned for '{title}'.")
            page_data = pages[0]
            if page_data.get("missing"):
                raise WikiArchiveError(f"The page '{title}' was not found on this wiki.")
            if page_record is None:
                page_record = PageRecord(
                    title=page_data.get("title", title),
                    namespace=int(page_data.get("ns", 0)),
                    page_id=str(page_data.get("pageid", "")),
                    revisions=[],
                )
            revisions = page_data.get("revisions", [])
            for revision_data in revisions:
                slot_data = revision_data.get("slots", {}).get("main", {})
                text_value = slot_data.get("content")
                if text_value is None:
                    text_value = revision_data.get("content", "")
                model = slot_data.get("contentmodel") or revision_data.get("contentmodel", "")
                format_name = slot_data.get("contentformat") or revision_data.get("contentformat", "")
                contributor = revision_data.get("user") or revision_data.get("anon") or ""
                bytes_count = int(revision_data.get("size", 0) or len((text_value or "").encode("utf-8")))
                page_record.revisions.append(
                    RevisionRecord(
                        revision_id=str(revision_data.get("revid", "")),
                        parent_id=str(revision_data.get("parentid", "")),
                        timestamp=revision_data.get("timestamp", ""),
                        contributor=str(contributor),
                        comment=revision_data.get("comment", ""),
                        model=model,
                        format_name=format_name,
                        sha1=revision_data.get("sha1", ""),
                        bytes_count=bytes_count,
                        text=text_value or "",
                    )
                )
            continuation = payload.get("continue", {})
            continue_token = continuation.get("rvcontinue")
            if latest_only or not continue_token:
                break
        if page_record is None:
            raise WikiArchiveError(f"The page '{title}' could not be loaded.")
        return siteinfo, page_record

    def check_updates(
        self,
        api_url: str,
        pages: list[PageIndexEntry],
        progress: Optional[Callable[[str], None]] = None,
    ) -> dict[str, str]:
        progress = progress or (lambda message: None)
        updates: dict[str, str] = {}
        total_batches = max(1, (len(pages) + 49) // 50)
        for batch_index, batch in enumerate(chunked(pages, 50), start=1):
            progress(f"Checking wiki updates… batch {batch_index} of {total_batches}")
            payload = self._request_json(
                api_url,
                {
                    "action": "query",
                    "prop": "revisions",
                    "titles": [page.title for page in batch],
                    "rvprop": "timestamp|ids",
                    "rvlimit": 1,
                },
            )
            returned_pages = payload.get("query", {}).get("pages", [])
            latest_map: dict[str, str] = {}
            for page_data in returned_pages:
                title = page_data.get("title", "")
                revisions = page_data.get("revisions", [])
                latest_map[normalize_title(title)] = revisions[0].get("timestamp", "") if revisions else ""
            for page in batch:
                latest_timestamp = latest_map.get(normalize_title(page.title), "")
                if latest_timestamp and latest_timestamp > page.latest_timestamp:
                    updates[page.title] = latest_timestamp
        return updates



class WikiDumpClient:
    def __init__(self, logger: Optional[Callable[[str], None]] = None) -> None:
        self.logger = logger or (lambda message: None)

    def _request_text(self, url: str) -> str:
        request = urllib.request.Request(
            url,
            headers={
                "User-Agent": USER_AGENT,
                "Accept": "text/html, text/plain;q=0.9, */*;q=0.1",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                raw = response.read()
                charset = response.headers.get_content_charset() or "utf-8"
        except urllib.error.HTTPError as exc:
            raise WikiArchiveError(f"Dump request failed with HTTP {exc.code}.") from exc
        except urllib.error.URLError as exc:
            raise WikiArchiveError(f"Dump request failed: {exc.reason}") from exc
        except Exception as exc:  # noqa: BLE001
            raise WikiArchiveError(f"Dump request failed: {exc}") from exc
        try:
            return raw.decode(charset, errors="replace")
        except Exception:
            return raw.decode("utf-8", errors="replace")

    def list_runs(
        self,
        dbname: str,
        downloaded_index: Optional[dict[tuple[str, str, str], dict[str, str]]] = None,
    ) -> list[DumpRun]:
        html_text = self._request_text(dump_root_url(dbname))
        entries = parse_directory_listing_entries(html_text, dump_root_url(dbname))
        runs: list[DumpRun] = []
        downloaded_runs: set[str] = set()
        for key in (downloaded_index or {}):
            if key[0] == dbname:
                downloaded_runs.add(key[1])
        for entry in entries:
            href = entry["href"]
            label = entry["label"]
            if href == "latest/":
                runs.append(
                    DumpRun(
                        dbname=dbname,
                        run="latest",
                        listed_at=entry["date"],
                        url=urllib.parse.urljoin(dump_root_url(dbname), href),
                        is_latest=True,
                        downloaded="latest" in downloaded_runs,
                    )
                )
                continue
            if not DUMP_DATE_PATTERN.fullmatch(href):
                continue
            run = href.rstrip("/")
            runs.append(
                DumpRun(
                    dbname=dbname,
                    run=run,
                    listed_at=entry["date"],
                    url=urllib.parse.urljoin(dump_root_url(dbname), href),
                    downloaded=run in downloaded_runs,
                )
            )
        runs.sort(key=lambda item: (0 if item.is_latest else 1, item.run), reverse=False)
        dated = [item for item in runs if not item.is_latest]
        dated.sort(key=lambda item: item.run, reverse=True)
        latest = [item for item in runs if item.is_latest]
        return latest + dated

    def list_files(
        self,
        dbname: str,
        run: str,
        downloaded_index: Optional[dict[tuple[str, str, str], dict[str, str]]] = None,
    ) -> list[DumpFile]:
        base_url = dump_run_url(dbname, run)
        html_text = self._request_text(base_url)
        entries = parse_directory_listing_entries(html_text, base_url)
        files: list[DumpFile] = []
        downloaded_index = downloaded_index or {}
        for entry in entries:
            href = entry["href"]
            filename = entry["label"]
            if href.endswith("/"):
                continue
            if filename.endswith("-rss.xml"):
                continue
            family, family_label = categorize_dump_filename(filename)
            supported = is_supported_dump_file(filename)
            files.append(
                DumpFile(
                    dbname=dbname,
                    run=run,
                    filename=filename,
                    url=urllib.parse.urljoin(base_url, href),
                    uploaded_at=entry["date"],
                    size_text=entry["size"],
                    family=family,
                    family_label=family_label,
                    supported=supported,
                    downloaded=(dbname, run, filename) in downloaded_index,
                )
            )
        files.sort(key=dump_file_sort_key)
        return files

    def recommend_file(self, dbname: str, run: str, choice_key: str, files: list[DumpFile]) -> Optional[DumpFile]:
        predicates: list[Callable[[str], bool]]
        if choice_key == "all_pages_current":
            predicates = [
                lambda name: "pages-meta-current.xml.bz2" in name and not is_partial_dump_name(name),
                lambda name: "pages-meta-current.xml.gz" in name and not is_partial_dump_name(name),
                lambda name: "pages-meta-current.xml" in name and not is_partial_dump_name(name),
            ]
        elif choice_key == "full_history":
            predicates = [
                lambda name: "pages-meta-history.xml.bz2" in name and not is_partial_dump_name(name),
                lambda name: "pages-meta-history.xml.gz" in name and not is_partial_dump_name(name),
                lambda name: "pages-meta-history.xml" in name and not is_partial_dump_name(name),
            ]
        else:
            predicates = [
                lambda name: "pages-articles-multistream.xml.bz2" in name and "-index" not in name and not is_partial_dump_name(name),
                lambda name: "pages-articles.xml.bz2" in name and not is_partial_dump_name(name),
                lambda name: "pages-meta-current.xml.bz2" in name and not is_partial_dump_name(name),
                lambda name: "pages-meta-current.xml.gz" in name and not is_partial_dump_name(name),
            ]
        lowered = [(file, file.filename.lower()) for file in files if file.supported]
        for predicate in predicates:
            for file, lower_name in lowered:
                if predicate(lower_name):
                    return file
        return None

    def download(
        self,
        url: str,
        destination: Path,
        progress: Optional[Callable[[str], None]] = None,
    ) -> Path:
        progress = progress or (lambda message: None)
        destination = destination.expanduser().resolve()
        ensure_directory(destination.parent)
        request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        try:
            with urllib.request.urlopen(request, timeout=120) as response, open(destination, "wb") as handle:
                total_header = response.headers.get("Content-Length") or ""
                total = int(total_header) if total_header.isdigit() else 0
                downloaded = 0
                chunk_size = 1024 * 1024
                while True:
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break
                    handle.write(chunk)
                    downloaded += len(chunk)
                    if total > 0:
                        percent = (downloaded / total) * 100
                        progress(
                            f"Downloading… {percent:0.02f}% ({human_size(downloaded)} of {human_size(total)})"
                        )
                    else:
                        progress(f"Downloading… {human_size(downloaded)}")
        except urllib.error.HTTPError as exc:
            raise WikiArchiveError(f"Archive download failed with HTTP {exc.code}.") from exc
        except urllib.error.URLError as exc:
            raise WikiArchiveError(f"Archive download failed: {exc.reason}") from exc
        except Exception as exc:  # noqa: BLE001
            raise WikiArchiveError(f"Archive download failed: {exc}") from exc
        return destination



# -----------------------------
# Formatting and text utilities
# -----------------------------

def format_dump_run(run: str) -> str:
    if not run or run == "latest":
        return run or ""
    if re.fullmatch(r"\d{8}", run):
        return f"{run[0:4]}-{run[4:6]}-{run[6:8]}"
    return run


def parse_directory_listing_entries(html_text: str, base_url: str) -> list[dict[str, str]]:
    entries: list[dict[str, str]] = []
    for match in DIRECTORY_ENTRY_PATTERN.finditer(html_text or ""):
        href = html.unescape(match.group("href")).strip()
        label = html.unescape(match.group("label")).strip()
        if href in {"../", "./"}:
            continue
        entries.append(
            {
                "href": href,
                "label": label,
                "date": match.group("date").strip(),
                "size": match.group("size").strip(),
                "url": urllib.parse.urljoin(base_url, href),
            }
        )
    return entries


def dump_root_url(dbname: str) -> str:
    dbname = (dbname or "").strip()
    if not dbname:
        raise WikiArchiveError("No wiki database name is available for dump browsing.")
    return f"https://dumps.wikimedia.org/{dbname}/"


def dump_run_url(dbname: str, run: str) -> str:
    clean_run = (run or "latest").rstrip("/") + "/"
    return urllib.parse.urljoin(dump_root_url(dbname), clean_run)


def is_partial_dump_name(filename: str) -> bool:
    return bool(DUMP_PART_PATTERN.search(filename.lower()))


def is_supported_dump_file(filename: str) -> bool:
    lower = filename.lower()
    if lower.endswith("-rss.xml"):
        return False
    return lower.endswith(".xml") or lower.endswith(".xml.bz2") or lower.endswith(".xml.gz")


def categorize_dump_filename(filename: str) -> tuple[str, str]:
    lower = filename.lower()
    if lower.endswith("md5sums.txt"):
        return ("checksums", "Checksums")
    if "pages-meta-current" in lower:
        return ("pages_meta_current", "All pages — current")
    if "pages-meta-history" in lower:
        return ("pages_meta_history", "All pages — history")
    if "pages-articles-multistream-index" in lower:
        return ("pages_articles_index", "Articles index")
    if "pages-articles-multistream" in lower:
        return ("pages_articles_multistream", "Articles — multistream")
    if "pages-articles" in lower:
        return ("pages_articles", "Articles — current")
    if "stub-meta-current" in lower:
        return ("stub_meta_current", "Stubs — current")
    if "stub-meta-history" in lower:
        return ("stub_meta_history", "Stubs — history")
    if "stub-articles" in lower:
        return ("stub_articles", "Article stubs")
    if "pages-logging" in lower:
        return ("logging", "Log events")
    if "abstract" in lower:
        return ("abstract", "Abstract pages")
    if lower.endswith(".sql.gz"):
        return ("sql", "SQL table")
    return ("other", "Other file")


def dump_scope_label(family: str) -> str:
    mapping = {
        "pages_meta_current": "Entire wiki — current revision",
        "pages_meta_history": "Entire wiki — full history",
        "pages_articles_multistream": "Article pages — multistream",
        "pages_articles": "Article pages",
        "stub_meta_current": "Stub pages — current revision",
        "stub_meta_history": "Stub pages — full history",
        "stub_articles": "Article stubs",
        "logging": "Log events",
        "abstract": "Abstract pages",
    }
    return mapping.get(family, "Archive file")


def grouped_dump_options(
    dbname: str,
    run: str,
    files: list[DumpFile],
    choice_key: str,
) -> list[DumpOption]:
    partial_groups: dict[tuple[str, str], list[DumpFile]] = {}
    single_files: list[DumpFile] = []
    for file in files:
        if not file.supported:
            continue
        lower_name = file.filename.lower()
        if file.family == "pages_articles_index":
            continue
        suffix = ".xml.bz2" if lower_name.endswith(".xml.bz2") else ".xml.gz" if lower_name.endswith(".xml.gz") else ".xml"
        if is_partial_dump_name(file.filename):
            partial_groups.setdefault((file.family, suffix), []).append(file)
        else:
            single_files.append(file)

    options: list[DumpOption] = []
    for index, ((family, suffix), group_files) in enumerate(sorted(partial_groups.items()), start=1):
        group_files = sorted(group_files, key=lambda item: item.filename.lower())
        total_size = sum(item.size_bytes or 0 for item in group_files)
        latest_uploaded = max((item.uploaded_at for item in group_files), default="")
        all_downloaded = all(item.downloaded for item in group_files)
        note = f"Downloads {len(group_files)} part files and indexes them as one local archive."
        options.append(
            DumpOption(
                option_id=f"group_{index}",
                dbname=dbname,
                run=run,
                title=f"{dump_scope_label(family)} (all parts)",
                scope_label=dump_scope_label(family),
                type_label="Multi-part set",
                uploaded_at=latest_uploaded,
                total_size_text=human_size(total_size) if total_size > 0 else "—",
                file_count=len(group_files),
                files=group_files,
                downloaded=all_downloaded,
                note=note,
            )
        )

    for index, file in enumerate(sorted(single_files, key=dump_file_sort_key), start=1):
        options.append(
            DumpOption(
                option_id=f"single_{index}",
                dbname=dbname,
                run=run,
                title=file.filename,
                scope_label=dump_scope_label(file.family),
                type_label="Single file",
                uploaded_at=file.uploaded_at,
                total_size_text=human_size(file.size_bytes or 0) if file.size_bytes else (file.size_text or "—"),
                file_count=1,
                files=[file],
                downloaded=file.downloaded,
                note=f"Downloads one archive file: {file.filename}",
            )
        )

    recommended = recommend_dump_option(choice_key, options)
    if recommended is not None:
        for option in options:
            option.recommended = option.option_id == recommended.option_id

    def sort_key(option: DumpOption) -> tuple[int, int, str]:
        family = option.files[0].family if option.files else "other"
        preferred_order = {
            "pages_articles_multistream": 0,
            "pages_articles": 1,
            "pages_meta_current": 2,
            "pages_meta_history": 3,
            "stub_meta_current": 4,
            "stub_meta_history": 5,
            "abstract": 6,
            "logging": 7,
            "other": 99,
        }
        return (preferred_order.get(family, 99), 0 if option.type_label == "Multi-part set" else 1, option.title.lower())

    options.sort(key=sort_key)
    return options


def recommend_dump_option(choice_key: str, options: list[DumpOption]) -> Optional[DumpOption]:
    family_preferences: list[str]
    if choice_key == "all_pages_current":
        family_preferences = ["pages_meta_current", "pages_articles_multistream", "pages_articles"]
    elif choice_key == "full_history":
        family_preferences = ["pages_meta_history", "stub_meta_history"]
    else:
        family_preferences = ["pages_articles_multistream", "pages_articles", "pages_meta_current"]
    for family in family_preferences:
        for option in options:
            if option.files and option.files[0].family == family:
                return option
    return options[0] if options else None


def dump_option_label(option: DumpOption) -> str:
    prefix = "★ " if option.recommended else ""
    return prefix + option.title


def dump_file_sort_key(file: DumpFile) -> tuple[int, int, str]:
    order = {
        "pages_articles_multistream": 0,
        "pages_articles": 1,
        "pages_meta_current": 2,
        "pages_meta_history": 3,
        "stub_meta_current": 4,
        "stub_meta_history": 5,
        "logging": 6,
        "abstract": 7,
        "checksums": 8,
        "sql": 9,
        "other": 10,
    }
    return (order.get(file.family, 99), 0 if file.supported else 1, file.filename.lower())


def human_size(size: int) -> str:
    value = float(size)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if value < 1024.0 or unit == "TB":
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} {unit}"
        value /= 1024.0
    return f"{size} B"


def bundle_kind_label(bundle: BundleEntry) -> str:
    mapping = {
        "full_dump": "Full dump",
        "downloaded": "Saved pages",
        "imported": "Imported",
    }
    return mapping.get(bundle.source_kind, bundle.source_kind.replace("_", " ").title())


def guess_dump_metadata_from_name(path: Path, siteinfo: SiteInfo) -> tuple[str, str, str]:
    name = path.name
    dbname = siteinfo.dbname or ""
    run = ""
    filename = ""
    match = re.match(r"(?P<db>[A-Za-z0-9_-]+)-(?P<run>\d{8}|\d{4}-\d{2}-\d{2})(?P<rest>.*)", name)
    if match:
        dbname = dbname or match.group("db")
        run = match.group("run").replace("-", "")
        filename = name
    return (dbname, run, filename)


def site_page_url(siteinfo: SiteInfo, title: str) -> str:
    title_part = urllib.parse.quote(title.replace(" ", "_"), safe=":/()'")
    base = siteinfo.base or ""
    parsed = urllib.parse.urlparse(base)
    if parsed.scheme and parsed.netloc:
        if "/wiki/" in parsed.path:
            prefix = parsed.path.split("/wiki/", 1)[0] + "/wiki/"
            return urllib.parse.urlunparse((parsed.scheme, parsed.netloc, prefix + title_part, "", "", ""))
        return urllib.parse.urlunparse((parsed.scheme, parsed.netloc, f"/wiki/{title_part}", "", "", ""))
    return title_part


def sanitize_html_id(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "-", value.strip())
    cleaned = cleaned.strip("-")
    return cleaned or "section"


def chunked(values: list[Any], size: int) -> Iterable[list[Any]]:
    for start in range(0, len(values), size):
        yield values[start : start + size]


def normalize_title(title: str) -> str:
    return title.strip().replace("_", " ").casefold()


def download_key(api_url: str, title: str) -> tuple[str, str]:
    return (api_url.strip().lower(), normalize_title(title))


def strip_html(text: str) -> str:
    cleaned = html.unescape(text or "")
    cleaned = HTML_TAG_PATTERN.sub(" ", cleaned)
    cleaned = MULTISPACE_PATTERN.sub(" ", cleaned)
    return cleaned.strip()


def namespace_label(namespace: int, namespaces: dict[int, str]) -> str:
    if namespace in namespaces:
        label = namespaces.get(namespace) or "Article"
        return label if label else "Article"
    if namespace == 0:
        return "Article"
    return str(namespace)


def extract_wikilinks(wikitext: str) -> list[str]:
    links: list[str] = []
    seen: set[str] = set()
    for raw in WIKILINK_PATTERN.findall(wikitext or ""):
        target = raw.split("|", 1)[0].split("#", 1)[0].strip()
        if not target:
            continue
        if target.startswith(":"):
            target = target[1:].strip()
        if target and target not in seen:
            seen.add(target)
            links.append(target)
    return links


def render_plain_text(wikitext: str, limit: int = 6000) -> str:
    text = html.unescape(wikitext or "")
    text = COMMENT_PATTERN.sub(" ", text)
    text = REF_PATTERN.sub(" ", text)
    for _ in range(10):
        new_text = TEMPLATE_PATTERN.sub(" ", text)
        if new_text == text:
            break
        text = new_text
    text = HTML_TAG_PATTERN.sub(" ", text)
    text = re.sub(r"^\s*={2,}\s*(.*?)\s*={2,}\s*$", r"\n\1\n", text, flags=re.M)
    text = re.sub(r"\[(https?://[^\s\]]+)\s+([^\]]+)\]", r"\2", text)
    text = re.sub(r"\[(https?://[^\]]+)\]", r"\1", text)
    text = re.sub(r"\[\[([^|\]]+)\|([^\]]+)\]\]", r"\2", text)
    text = re.sub(r"\[\[([^\]]+)\]\]", r"\1", text)
    text = text.replace("'''", "").replace("''", "")
    text = re.sub(r"^[*#;:]+\s*", "• ", text, flags=re.M)
    text = MULTISPACE_PATTERN.sub(" ", text)
    text = MULTINEWLINE_PATTERN.sub("\n\n", text)
    text = text.strip()
    if len(text) > limit:
        text = text[:limit].rstrip() + "…"
    return text



def preview_html_filename(title: str) -> str:
    digest = hashlib.sha1(title.encode("utf-8")).hexdigest()[:10]
    stem = sanitize_filename(title.replace("/", "_")) or "page"
    return f"{stem}_{digest}.html"


def _inline_wikitext_html(text: str, siteinfo: SiteInfo, local_hrefs: dict[str, str]) -> str:
    placeholders: dict[str, str] = {}

    def stash(value: str) -> str:
        key = f"@@HTML{len(placeholders)}@@"
        placeholders[key] = value
        return key

    def link_target(raw_target: str) -> str:
        target = raw_target.split("#", 1)[0].strip()
        if target.startswith(":"):
            target = target[1:].strip()
        return target

    def replace_external(match: re.Match[str]) -> str:
        url = match.group(1)
        label = match.group(2) if match.lastindex and match.lastindex > 1 else url
        safe_url = html.escape(url, quote=True)
        safe_label = html.escape((label or url).strip(), quote=False)
        return stash(f'<a href="{safe_url}">{safe_label}</a>')

    def replace_wikilink(match: re.Match[str]) -> str:
        raw = match.group(1)
        target_text, _, label_text = raw.partition("|")
        target = link_target(target_text)
        label = label_text.strip() or target
        href = local_hrefs.get(target) or (site_page_url(siteinfo, target) if target else "")
        safe_label = html.escape(label, quote=False)
        if href:
            return stash(f'<a href="{html.escape(href, quote=True)}">{safe_label}</a>')
        return safe_label

    text = re.sub(r"\[(https?://[^\s\]]+)\s+([^\]]+)\]", replace_external, text)
    text = re.sub(r"\[(https?://[^\]]+)\]", lambda match: replace_external(match), text)
    text = re.sub(r"\[\[([^\]]+)\]\]", replace_wikilink, text)
    text = html.escape(text, quote=False)
    text = re.sub(r"'''''(.*?)'''''", r"<strong><em>\1</em></strong>", text)
    text = re.sub(r"'''(.*?)'''", r"<strong>\1</strong>", text)
    text = re.sub(r"''(.*?)''", r"<em>\1</em>", text)
    for key, value in placeholders.items():
        text = text.replace(key, value)
    return text


def render_wikitext_basic_html(wikitext: str, siteinfo: SiteInfo, local_hrefs: Optional[dict[str, str]] = None) -> str:
    local_hrefs = local_hrefs or {}
    text = html.unescape(wikitext or "")
    text = COMMENT_PATTERN.sub(" ", text)
    text = REF_PATTERN.sub(" ", text)
    for _ in range(10):
        new_text = TEMPLATE_PATTERN.sub(" ", text)
        if new_text == text:
            break
        text = new_text
    text = HTML_TAG_PATTERN.sub(" ", text)
    lines = text.splitlines()
    parts: list[str] = []
    list_stack: list[str] = []
    paragraph: list[str] = []

    def flush_paragraph() -> None:
        if not paragraph:
            return
        joined = " ".join(item.strip() for item in paragraph if item.strip())
        content = _inline_wikitext_html(joined, siteinfo, local_hrefs)
        if content.strip():
            parts.append(f"<p>{content}</p>")
        paragraph.clear()

    def close_lists() -> None:
        while list_stack:
            tag = list_stack.pop()
            parts.append(f"</{tag}>")

    for raw_line in lines:
        stripped = raw_line.strip()
        if not stripped:
            flush_paragraph()
            close_lists()
            continue
        heading = re.match(r"^(={2,6})\s*(.*?)\s*\1\s*$", stripped)
        if heading:
            flush_paragraph()
            close_lists()
            level = min(len(heading.group(1)), 6)
            title = _inline_wikitext_html(heading.group(2), siteinfo, local_hrefs)
            parts.append(f"<h{level}>{title}</h{level}>")
            continue
        list_match = re.match(r"^([*#]+)\s*(.*)$", stripped)
        if list_match:
            flush_paragraph()
            markers = list_match.group(1)
            item_html = _inline_wikitext_html(list_match.group(2), siteinfo, local_hrefs)
            desired = ["ul" if mark == "*" else "ol" for mark in markers]
            common = 0
            while common < len(list_stack) and common < len(desired) and list_stack[common] == desired[common]:
                common += 1
            while len(list_stack) > common:
                tag = list_stack.pop()
                parts.append(f"</{tag}>")
            for tag in desired[common:]:
                parts.append(f"<{tag}>")
                list_stack.append(tag)
            parts.append(f"<li>{item_html}</li>")
            continue
        close_lists()
        paragraph.append(stripped)

    flush_paragraph()
    close_lists()
    return "\n".join(parts) if parts else "<p>(No readable content was generated.)</p>"


def local_preview_css() -> str:
    return (
        "body { background:#f8f9fa; color:#202122; font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif; margin:0; }\n"
        "#page { max-width:980px; margin:0 auto; background:white; min-height:100vh; box-shadow:0 0 0 1px #eaecf0; }\n"
        "header { border-bottom:1px solid #eaecf0; padding:20px 28px 12px; background:#fbfbfb; }\n"
        "header h1 { margin:0 0 8px; font-size:2rem; font-weight:500; }\n"
        "header .meta { color:#54595d; font-size:.95rem; }\n"
        "main { padding:24px 28px 40px; line-height:1.6; }\n"
        "a { color:#3366cc; text-decoration:none; }\n"
        "a:hover { text-decoration:underline; }\n"
        "p { margin:0 0 1em; }\n"
        "h2,h3,h4,h5,h6 { border-bottom:1px solid #eaecf0; padding-bottom:.2em; margin-top:1.6em; font-weight:500; }\n"
        "ul,ol { margin:0 0 1em 1.6em; }\n"
        ".box { background:#f8f9fa; border:1px solid #eaecf0; border-radius:8px; padding:12px 14px; margin:0 0 18px; }\n"
        "pre { white-space:pre-wrap; word-break:break-word; background:#f8f9fa; border:1px solid #eaecf0; border-radius:6px; padding:12px; }\n"
        "details { margin-top:24px; }\n"
        "small.muted { color:#72777d; }\n"
    )


def build_local_page_html(page: PageRecord, siteinfo: SiteInfo, local_hrefs: Optional[dict[str, str]] = None) -> str:
    local_hrefs = local_hrefs or {}
    latest = page.latest_revision
    body_html = render_wikitext_basic_html(latest.text if latest else "", siteinfo, local_hrefs)
    latest_display = safe_local_time(latest.timestamp) if latest else "Unknown"
    source_url = site_page_url(siteinfo, page.title)
    raw_text = html.escape(latest.text if latest else "")
    namespace_name = namespace_label(page.namespace, siteinfo.namespaces)
    lines = [
        "<!doctype html>",
        '<html lang="en">',
        "<head>",
        '  <meta charset="utf-8">',
        '  <meta name="viewport" content="width=device-width, initial-scale=1">',
        f"  <title>{html.escape(page.title)} — {html.escape(siteinfo.sitename or 'Local Wiki Preview')}</title>",
        f"  <style>{local_preview_css()}</style>",
        "</head>",
        "<body>",
        '  <div id="page">',
        "    <header>",
        f"      <h1>{html.escape(page.title)}</h1>",
        f'      <div class="meta">{html.escape(siteinfo.sitename or "Local Wiki Preview")} • {html.escape(namespace_name)} • Latest edit: {html.escape(latest_display)}</div>',
        "    </header>",
        "    <main>",
        '      <div class="box">',
        f"        <div><strong>Page ID:</strong> {html.escape(page.page_id or '—')}</div>",
        f"        <div><strong>Revisions:</strong> {len(page.revisions)}</div>",
        f'        <div><strong>Open live page:</strong> <a href="{html.escape(source_url, quote=True)}">{html.escape(source_url)}</a></div>',
        "      </div>",
        f"      {body_html}",
        "      <details>",
        "        <summary>Show raw wikitext</summary>",
        f"        <pre>{raw_text}</pre>",
        "      </details>",
        '      <p><small class="muted">This page was rendered locally from the archive and is only a basic wiki-style preview.</small></p>',
        "    </main>",
        "  </div>",
        "</body>",
        "</html>",
    ]
    return "\n".join(lines)

# -----------------------------
# File and archive helpers
# -----------------------------

def detect_bundle_type(path: Path) -> str:
    name = path.name.lower()
    if name.endswith(".xml.bz2"):
        return "xml.bz2"
    if name.endswith(".xml.gz"):
        return "xml.gz"
    if name.endswith(".xml"):
        return "xml"
    raise WikiArchiveError("Only .xml, .xml.bz2, and .xml.gz files are supported.")


def file_fingerprint(path: Path) -> str:
    stat = path.stat()
    value = f"{path.resolve()}|{stat.st_size}|{stat.st_mtime_ns}"
    return hashlib.sha1(value.encode("utf-8")).hexdigest()


def combined_fingerprint(paths: list[Path]) -> str:
    values: list[str] = []
    for path in paths:
        resolved = path.expanduser().resolve()
        stat = resolved.stat()
        values.append(f"{resolved}|{stat.st_size}|{stat.st_mtime_ns}")
    return hashlib.sha1("\n".join(values).encode("utf-8")).hexdigest()


def bundle_source_paths(bundle: BundleEntry) -> list[Path]:
    source_files = [Path(item) for item in (bundle.source_files or [])]
    if source_files:
        return source_files
    return [Path(bundle.path)]


def bundle_path_exists(bundle: BundleEntry) -> bool:
    source_paths = bundle_source_paths(bundle)
    if bundle.source_files:
        return all(path.exists() for path in source_paths)
    return source_paths[0].exists()


def bundle_path_label(bundle: BundleEntry) -> str:
    if bundle.source_files:
        return f"{bundle.path} ({len(bundle.source_files)} files)"
    return bundle.path


def api_url_from_base(base_url: str) -> str:
    if not base_url:
        return ""
    parsed = urllib.parse.urlparse(base_url)
    if not parsed.scheme or not parsed.netloc:
        return ""
    return f"{parsed.scheme}://{parsed.netloc}/w/api.php"


def project_api_url(project_name: str, language_code: str) -> str:
    if project_name in FIXED_PROJECTS:
        return FIXED_PROJECTS[project_name]
    suffix = LANGUAGE_PROJECTS.get(project_name)
    if not suffix:
        raise WikiArchiveError("Please choose a supported Wikimedia project.")
    code = (language_code or "en").strip().lower()
    if not re.fullmatch(r"[a-z0-9-]+", code):
        raise WikiArchiveError("Language code should use letters, numbers, or hyphens only.")
    return f"https://{code}.{suffix}/w/api.php"


def state_bundle_name_from_path(path: Path) -> str:
    return path.name


def unique_bundle_name(folder: Path, requested_stem: str, extension: str) -> Path:
    safe_stem = sanitize_filename(requested_stem or "wiki_bundle")
    candidate = folder / f"{safe_stem}{extension}"
    counter = 2
    while candidate.exists():
        candidate = folder / f"{safe_stem}_{counter}{extension}"
        counter += 1
    return candidate


def sanitize_filename(name: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", name.strip())
    cleaned = cleaned.strip("._")
    return cleaned or "wiki_bundle"


def opener_for_path(path: Path):
    name = path.name.lower()
    if name.endswith('.bz2'):
        return bz2.open
    if name.endswith('.gz'):
        return gzip.open
    return open


def parse_siteinfo_from_element(siteinfo_element: ET.Element) -> SiteInfo:
    siteinfo = SiteInfo(
        sitename=siteinfo_element.findtext(ns_tag("sitename")) or "",
        dbname=siteinfo_element.findtext(ns_tag("dbname")) or "",
        base=siteinfo_element.findtext(ns_tag("base")) or "",
        generator=siteinfo_element.findtext(ns_tag("generator")) or "",
        case=siteinfo_element.findtext(ns_tag("case")) or "first-letter",
        lang=siteinfo_element.get(f"{{{XML_SPACE_NS}}}lang", "en"),
        namespaces={},
        api_url="",
    )
    namespaces_parent = siteinfo_element.find(ns_tag("namespaces"))
    if namespaces_parent is not None:
        for namespace_element in namespaces_parent.findall(ns_tag("namespace")):
            try:
                key = int(namespace_element.get("key") or "0")
            except ValueError:
                continue
            siteinfo.namespaces[key] = namespace_element.text or ""
    siteinfo.api_url = api_url_from_base(siteinfo.base)
    return siteinfo


def build_archive_index(path: Path) -> tuple[SiteInfo, list[PageIndexEntry], int]:
    path = path.expanduser().resolve()
    opener = opener_for_path(path)
    siteinfo = SiteInfo()
    page_index: list[PageIndexEntry] = []
    revision_total = 0
    with opener(path, "rb") as handle:
        for _event, element in ET.iterparse(handle, events=("end",)):
            tag = element.tag.rsplit("}", 1)[-1]
            if tag == "siteinfo":
                siteinfo = parse_siteinfo_from_element(element)
                element.clear()
            elif tag == "page":
                title = element.findtext(ns_tag("title")) or ""
                namespace = int(element.findtext(ns_tag("ns")) or "0")
                page_id = element.findtext(ns_tag("id")) or ""
                revisions = element.findall(ns_tag("revision"))
                revision_count = len(revisions)
                revision_total += revision_count
                latest_timestamp = ""
                if revisions:
                    latest_timestamp = revisions[-1].findtext(ns_tag("timestamp")) or ""
                page_index.append(
                    PageIndexEntry(
                        title=title,
                        namespace=namespace,
                        page_id=page_id,
                        latest_timestamp=latest_timestamp,
                        revision_count=revision_count,
                    )
                )
                element.clear()
    if not siteinfo.api_url:
        siteinfo.api_url = api_url_from_base(siteinfo.base)
    return siteinfo, page_index, revision_total


def build_archive_index_many(paths: list[Path]) -> tuple[SiteInfo, list[PageIndexEntry], int]:
    resolved_paths = [path.expanduser().resolve() for path in paths]
    if not resolved_paths:
        raise WikiArchiveError("No archive files were provided.")
    siteinfo = SiteInfo()
    page_index: list[PageIndexEntry] = []
    revision_total = 0
    for path in resolved_paths:
        current_siteinfo, current_page_index, current_revision_total = build_archive_index(path)
        if not siteinfo.sitename:
            siteinfo = current_siteinfo
        page_index.extend(current_page_index)
        revision_total += current_revision_total
    if not siteinfo.api_url:
        siteinfo.api_url = api_url_from_base(siteinfo.base)
    return siteinfo, page_index, revision_total


def _page_from_xml_element(page_element: ET.Element) -> PageRecord:
    title = page_element.findtext(ns_tag("title")) or ""
    namespace = int(page_element.findtext(ns_tag("ns")) or "0")
    page_id = page_element.findtext(ns_tag("id")) or ""
    revisions: list[RevisionRecord] = []
    for revision_element in page_element.findall(ns_tag("revision")):
        contributor_element = revision_element.find(ns_tag("contributor"))
        contributor = ""
        if contributor_element is not None:
            contributor = (
                contributor_element.findtext(ns_tag("username"))
                or contributor_element.findtext(ns_tag("ip"))
                or ""
            )
        text_element = revision_element.find(ns_tag("text"))
        text_value = text_element.text if text_element is not None and text_element.text else ""
        bytes_value = 0
        if text_element is not None:
            bytes_attr = text_element.get("bytes")
            if bytes_attr and bytes_attr.isdigit():
                bytes_value = int(bytes_attr)
            else:
                bytes_value = len(text_value.encode("utf-8"))
        revisions.append(
            RevisionRecord(
                revision_id=revision_element.findtext(ns_tag("id")) or "",
                parent_id=revision_element.findtext(ns_tag("parentid")) or "",
                timestamp=revision_element.findtext(ns_tag("timestamp")) or "",
                contributor=contributor,
                comment=revision_element.findtext(ns_tag("comment")) or "",
                model=revision_element.findtext(ns_tag("model")) or "",
                format_name=revision_element.findtext(ns_tag("format")) or "",
                sha1=revision_element.findtext(ns_tag("sha1")) or "",
                bytes_count=bytes_value,
                text=text_value,
            )
        )
    return PageRecord(title=title, namespace=namespace, page_id=page_id, revisions=revisions)


def extract_page_from_archive(path: Path, page_title: str) -> PageRecord:
    path = path.expanduser().resolve()
    opener = opener_for_path(path)
    with opener(path, "rb") as handle:
        for _event, element in ET.iterparse(handle, events=("end",)):
            if element.tag.rsplit("}", 1)[-1] != "page":
                continue
            title = element.findtext(ns_tag("title")) or ""
            if title == page_title:
                page = _page_from_xml_element(element)
                element.clear()
                return page
            element.clear()
    raise WikiArchiveError(f"Page '{page_title}' was not found in this archive.")


def extract_page_from_archive_many(paths: list[Path], page_title: str) -> PageRecord:
    resolved_paths = [path.expanduser().resolve() for path in paths]
    last_error: Optional[Exception] = None
    for path in resolved_paths:
        try:
            return extract_page_from_archive(path, page_title)
        except Exception as exc:  # noqa: BLE001
            last_error = exc
            continue
    if last_error is not None and len(resolved_paths) == 1:
        raise last_error
    raise WikiArchiveError(f"Page '{page_title}' was not found in this archive.")


def page_cache_folder(bundle: BundleEntry) -> Path:
    folder = CACHE_HOME / bundle.entry_id / bundle.fingerprint
    return ensure_directory(folder)


def page_cache_path(bundle: BundleEntry, page_title: str) -> Path:
    cache_name = hashlib.sha1(page_title.encode("utf-8")).hexdigest() + ".json"
    return page_cache_folder(bundle) / cache_name


def load_cached_page(bundle: BundleEntry, page_title: str) -> Optional[PageRecord]:
    path = page_cache_path(bundle, page_title)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    revisions = [RevisionRecord(**item) for item in data.get("revisions", [])]
    return PageRecord(
        title=data.get("title", page_title),
        namespace=int(data.get("namespace", 0)),
        page_id=str(data.get("page_id", "")),
        revisions=revisions,
    )


def save_cached_page(bundle: BundleEntry, page: PageRecord) -> None:
    path = page_cache_path(bundle, page.title)
    data = {
        "title": page.title,
        "namespace": page.namespace,
        "page_id": page.page_id,
        "revisions": [asdict(revision) for revision in page.revisions],
    }
    path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")


# -----------------------------
# XML export builder
# -----------------------------

def siteinfo_for_export(siteinfo: SiteInfo) -> SiteInfo:
    result = SiteInfo(
        sitename=siteinfo.sitename or "Wikimedia Bundle",
        dbname=siteinfo.dbname or derive_dbname_from_api(siteinfo.api_url),
        base=siteinfo.base,
        generator=siteinfo.generator or f"{APP_NAME} {APP_VERSION}",
        case=siteinfo.case or "first-letter",
        lang=siteinfo.lang or "en",
        namespaces=dict(siteinfo.namespaces or {}),
        api_url=siteinfo.api_url,
    )
    if 0 not in result.namespaces:
        result.namespaces[0] = ""
    return result


def derive_dbname_from_api(api_url: str) -> str:
    if not api_url:
        return "wiki"
    parsed = urllib.parse.urlparse(api_url)
    host = parsed.netloc.split(":", 1)[0]
    return host.replace(".", "_")


def build_mediawiki_xml(siteinfo: SiteInfo, pages: list[PageRecord]) -> bytes:
    siteinfo = siteinfo_for_export(siteinfo)
    root = ET.Element(
        ns_tag("mediawiki"),
        {
            f"{{{XSI_NS_URI}}}schemaLocation": f"{XML_NS_URI} {XML_NS_URI}.xsd",
            "version": "0.11",
            f"{{{XML_SPACE_NS}}}lang": siteinfo.lang or "en",
        },
    )
    siteinfo_element = ET.SubElement(root, ns_tag("siteinfo"))
    for tag_name, value in [
        ("sitename", siteinfo.sitename),
        ("dbname", siteinfo.dbname),
        ("base", siteinfo.base),
        ("generator", siteinfo.generator),
        ("case", siteinfo.case),
    ]:
        child = ET.SubElement(siteinfo_element, ns_tag(tag_name))
        child.text = value or ""
    namespaces_element = ET.SubElement(siteinfo_element, ns_tag("namespaces"))
    for key in sorted(siteinfo.namespaces):
        namespace_element = ET.SubElement(
            namespaces_element,
            ns_tag("namespace"),
            {"key": str(key), "case": siteinfo.case or "first-letter"},
        )
        namespace_element.text = siteinfo.namespaces[key] or None

    for page in pages:
        page_element = ET.SubElement(root, ns_tag("page"))
        ET.SubElement(page_element, ns_tag("title")).text = page.title
        ET.SubElement(page_element, ns_tag("ns")).text = str(page.namespace)
        ET.SubElement(page_element, ns_tag("id")).text = str(page.page_id)
        for revision in page.revisions:
            revision_element = ET.SubElement(page_element, ns_tag("revision"))
            ET.SubElement(revision_element, ns_tag("id")).text = str(revision.revision_id)
            if revision.parent_id:
                ET.SubElement(revision_element, ns_tag("parentid")).text = str(revision.parent_id)
            ET.SubElement(revision_element, ns_tag("timestamp")).text = revision.timestamp
            if revision.contributor:
                contributor_element = ET.SubElement(revision_element, ns_tag("contributor"))
                if re.fullmatch(r"\d{1,3}(?:\.\d{1,3}){3}", revision.contributor):
                    ET.SubElement(contributor_element, ns_tag("ip")).text = revision.contributor
                else:
                    ET.SubElement(contributor_element, ns_tag("username")).text = revision.contributor
            if revision.comment:
                ET.SubElement(revision_element, ns_tag("comment")).text = revision.comment
            if revision.model:
                ET.SubElement(revision_element, ns_tag("model")).text = revision.model
            if revision.format_name:
                ET.SubElement(revision_element, ns_tag("format")).text = revision.format_name
            text_element = ET.SubElement(revision_element, ns_tag("text"))
            text_element.set("bytes", str(revision.bytes_count or len((revision.text or "").encode("utf-8"))))
            text_element.set(f"{{{XML_SPACE_NS}}}space", "preserve")
            text_element.text = revision.text or ""
            if revision.sha1:
                ET.SubElement(revision_element, ns_tag("sha1")).text = revision.sha1
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def save_bundle_file(siteinfo: SiteInfo, pages: list[PageRecord], output_path: Path) -> Path:
    output_path = output_path.expanduser().resolve()
    xml_bytes = build_mediawiki_xml(siteinfo, pages)
    lower_name = output_path.name.lower()
    if lower_name.endswith('.bz2'):
        with bz2.open(output_path, 'wb') as handle:
            handle.write(xml_bytes)
    elif lower_name.endswith('.gz'):
        with gzip.open(output_path, 'wb') as handle:
            handle.write(xml_bytes)
    else:
        output_path.write_bytes(xml_bytes)
    return output_path


# -----------------------------
# Bundle metadata helpers
# -----------------------------

def build_bundle_entry(
    *,
    path: Path,
    siteinfo: SiteInfo,
    page_index: list[PageIndexEntry],
    revision_total: int,
    source_kind: str,
    managed_copy: bool,
    existing_entry_id: Optional[str] = None,
    existing_added_at: Optional[str] = None,
    remote_source_url: str = "",
    dump_dbname: str = "",
    dump_run: str = "",
    dump_filename: str = "",
    source_files: Optional[list[Path]] = None,
    dump_filenames: Optional[list[str]] = None,
    name_override: str = "",
    fingerprint_override: str = "",
    bundle_type_override: str = "",
) -> BundleEntry:
    resolved = path.expanduser().resolve()
    resolved_sources = [item.expanduser().resolve() for item in (source_files or [resolved])]
    bundle_type = bundle_type_override or ("xml-set" if len(resolved_sources) > 1 else detect_bundle_type(resolved))
    entry_id = existing_entry_id or uuid.uuid4().hex
    added_at = existing_added_at or now_utc_iso()
    guessed_dbname, guessed_run, guessed_filename = guess_dump_metadata_from_name(resolved_sources[0], siteinfo)
    dump_dbname = dump_dbname or guessed_dbname
    dump_run = dump_run or guessed_run
    normalized_dump_filenames = [item for item in (dump_filenames or []) if item]
    if dump_filename and dump_filename not in normalized_dump_filenames:
        normalized_dump_filenames.insert(0, dump_filename)
    if not dump_filename and guessed_filename and guessed_filename not in normalized_dump_filenames:
        normalized_dump_filenames.insert(0, guessed_filename)
    dump_filename = dump_filename or guessed_filename or (normalized_dump_filenames[0] if len(normalized_dump_filenames) == 1 else (f"{len(normalized_dump_filenames)} files" if normalized_dump_filenames else ""))
    site_name = siteinfo.sitename or (resolved.stem if resolved.is_file() else resolved.name)
    return BundleEntry(
        entry_id=entry_id,
        name=name_override or state_bundle_name_from_path(resolved),
        path=str(resolved),
        bundle_type=bundle_type,
        source_kind=source_kind,
        site_name=site_name,
        api_url=siteinfo.api_url,
        base_url=siteinfo.base,
        dbname=siteinfo.dbname,
        page_count=len(page_index),
        revision_count=revision_total,
        pages=page_index,
        added_at=added_at,
        managed_copy=managed_copy,
        fingerprint=fingerprint_override or (combined_fingerprint(resolved_sources) if len(resolved_sources) > 1 else file_fingerprint(resolved)),
        site_lang=siteinfo.lang or "en",
        site_case=siteinfo.case or "first-letter",
        site_generator=siteinfo.generator or "",
        site_namespaces=dict(siteinfo.namespaces or {}),
        remote_source_url=remote_source_url,
        dump_dbname=dump_dbname,
        dump_run=dump_run,
        dump_filename=dump_filename,
        source_files=[str(item) for item in resolved_sources],
        dump_filenames=normalized_dump_filenames,
    )

def loaded_archive_from_bundle(bundle: BundleEntry) -> LoadedArchive:
    siteinfo = SiteInfo(
        sitename=bundle.site_name,
        dbname=bundle.dbname,
        base=bundle.base_url,
        generator=bundle.site_generator,
        case=bundle.site_case or "first-letter",
        lang=bundle.site_lang or "en",
        namespaces=dict(bundle.site_namespaces or {}),
        api_url=bundle.api_url,
    )
    return LoadedArchive(
        title=bundle.name,
        source_label=bundle.site_name or bundle.name,
        source_path=bundle.path,
        siteinfo=siteinfo,
        page_index=bundle.pages,
        pages={},
    )


def import_archive_file(path: Path, store: StateStore) -> BundleEntry:
    resolved = path.expanduser().resolve()
    if not resolved.exists():
        raise WikiArchiveError("The selected file does not exist.")
    bundle_type = detect_bundle_type(resolved)
    _ = bundle_type  # validated
    siteinfo, page_index, revision_total = build_archive_index(resolved)
    existing = store.bundle_by_path(str(resolved))
    entry = build_bundle_entry(
        path=resolved,
        siteinfo=siteinfo,
        page_index=page_index,
        revision_total=revision_total,
        source_kind="imported",
        managed_copy=is_managed_copy(resolved, store.archive_folder()),
        existing_entry_id=existing.entry_id if existing else None,
        existing_added_at=existing.added_at if existing else None,
    )
    entry.last_opened_at = existing.last_opened_at if existing else ""
    entry.last_checked_at = existing.last_checked_at if existing else ""
    entry.update_count = existing.update_count if existing else 0
    store.upsert_bundle(entry)
    return entry


def is_managed_copy(path: Path, archive_folder: Path) -> bool:
    try:
        return path.expanduser().resolve().is_relative_to(archive_folder.expanduser().resolve())
    except Exception:
        return False


def archive_copy(bundle: BundleEntry, store: StateStore) -> BundleEntry:
    if len(bundle_source_paths(bundle)) > 1 or Path(bundle.path).is_dir():
        raise WikiArchiveError("Multi-file full wiki archives are already stored as managed archive folders and cannot be copied as one file.")
    source_path = Path(bundle.path)
    if not source_path.exists():
        raise WikiArchiveError("The selected archive file could not be found.")
    archive_folder = store.archive_folder()
    destination = archive_folder / source_path.name
    counter = 2
    while destination.exists() and destination.resolve() != source_path.resolve():
        base_name = source_path.name
        if base_name.lower().endswith(".xml.bz2"):
            stem = base_name[:-8]
            suffix = ".xml.bz2"
        else:
            stem = source_path.stem
            suffix = source_path.suffix
        destination = archive_folder / f"{sanitize_filename(stem)}_{counter}{suffix}"
        counter += 1
    if destination.resolve() != source_path.resolve():
        shutil.copy2(source_path, destination)
    return import_archive_file(destination, store)


def remove_missing_cache(bundle: BundleEntry) -> None:
    cache_root = CACHE_HOME / bundle.entry_id
    if cache_root.exists() and bundle.fingerprint:
        for child in cache_root.iterdir():
            if child.name != bundle.fingerprint:
                shutil.rmtree(child, ignore_errors=True)


def bundle_summary_text(bundle: BundleEntry) -> str:
    lines = [
        f"Archive name: {bundle.name}",
        f"Archive kind: {bundle_kind_label(bundle)}",
        f"Source wiki: {bundle.site_name or 'Unknown'}",
        f"Pages in archive: {bundle.page_count}",
        f"Revisions in archive: {bundle.revision_count}",
        f"Saved path: {bundle_path_label(bundle)}",
        f"Added to library: {safe_local_time(bundle.added_at)}",
    ]
    if len(bundle.source_files) > 1:
        lines.append(f"Archive files in set: {len(bundle.source_files)}")
    if bundle.dump_run:
        lines.append(f"Dump date: {format_dump_run(bundle.dump_run)}")
    if bundle.dump_filename:
        lines.append(f"Dump file: {bundle.dump_filename}")
    if bundle.last_opened_at:
        lines.append(f"Last opened: {safe_local_time(bundle.last_opened_at)}")
    if bundle.last_checked_at:
        lines.append(f"Last checked for updates: {safe_local_time(bundle.last_checked_at)}")
        lines.append(f"Updates found: {bundle.update_count}")
    lines.append(f"Managed archive copy: {'Yes' if bundle.managed_copy else 'No'}")
    return "\n".join(lines)


def page_summary_text(page: PageRecord, namespaces: dict[int, str]) -> str:
    latest = page.latest_revision
    lines = [
        f"Title: {page.title}",
        f"Namespace: {namespace_label(page.namespace, namespaces)}",
        f"Page ID: {page.page_id}",
        f"Revision count: {len(page.revisions)}",
    ]
    if latest:
        lines.extend(
            [
                f"Latest edit: {safe_local_time(latest.timestamp)}",
                f"Latest contributor: {latest.contributor or 'Unknown'}",
                f"Latest comment: {latest.comment or '—'}",
                f"Latest model: {latest.model or '—'}",
                f"Latest format: {latest.format_name or '—'}",
                f"Latest size: {latest.bytes_count} bytes",
                f"Internal links detected: {len(extract_wikilinks(latest.text))}",
            ]
        )
    return "\n".join(lines)


def page_xml_snippet(page: PageRecord, siteinfo: SiteInfo) -> str:
    xml_bytes = build_mediawiki_xml(siteinfo_for_export(siteinfo), [page])
    return xml_bytes.decode("utf-8", errors="replace")


def exception_text(exc: BaseException) -> str:
    return "\n".join(traceback.format_exception(exc))
