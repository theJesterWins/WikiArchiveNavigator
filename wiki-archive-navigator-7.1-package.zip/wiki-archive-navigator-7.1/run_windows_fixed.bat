@echo off
setlocal
cd /d "%~dp0"

call :find_python || goto :error

echo Starting Wiki Archive Navigator...
%PY_CMD% app.py
if errorlevel 1 goto :error
exit /b 0

:find_python
where py >nul 2>nul
if not errorlevel 1 (
    set "PY_CMD=py -3"
    exit /b 0
)

where python >nul 2>nul
if not errorlevel 1 (
    set "PY_CMD=python"
    exit /b 0
)

echo.
echo Python 3 was not found.
echo.
echo This package includes the app source, but Windows still needs a local Python install to run it.
echo Try one of these:
echo   1. Install Python 3 from python.org and tick "Add Python to PATH"
echo   2. If Python is already installed, turn off the Microsoft Store aliases for python.exe and python3.exe
exit /b 1

:error
echo.
echo Launch failed.
pause
exit /b 1
