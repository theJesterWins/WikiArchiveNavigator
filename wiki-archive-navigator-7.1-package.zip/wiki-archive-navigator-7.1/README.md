# Wiki Archive Navigator

Wiki Archive Navigator is a plain desktop app for three jobs:

- keep a library of imported or downloaded Wikimedia archives
- either **search and save pages** or **download an entire wiki archive**
- open pages as local **wiki-style webpages**

## What changed in this revision

This revision simplifies the reading side of the app:

- the old **Reader & Interpretation** pane is gone
- the right side is now a simpler **Archive Pages** list
- double-clicking a page row opens a local wiki-style webpage
- search results can also be opened directly as local webpages
- the page browser includes a simple filter so large archives are easier to narrow down

The safer whole-archive flow from the last revision is still in place:

- **Search & Save Pages** is still the first tab and the best default path
- **Download Entire Wiki** still uses the clearer step flow
- a **review panel** still explains exactly what the highlighted whole-archive choice will do
- the **Start whole-archive download** button still stays disabled until the confirmation box is checked
- the final confirmation dialog still repeats the size, scope, and file count before starting
- download progress still shows **decimal percentages** instead of sitting on `0%`

## Main layout

- **Archive Library** — imported archives and completed downloads
- **Wiki Download & Storage**
  - **Search & Save Pages** — search the live wiki and save only what you want
  - **Download Entire Wiki** — full wiki archive workflow with review and confirmation
  - **Activity & Help** — log and walkthrough
- **Buttons in Between** — archive actions and quick open actions
- **Archive Pages** — pages from the currently loaded archive, with double-click to open HTML

## Best starting point

Most people should start with **Search & Save Pages**.

Use **Download Entire Wiki** only when you really want a full archive for that wiki and date.

## Search & Save Pages workflow

1. Choose a Wikimedia project and language.
2. Open **Search & Save Pages**.
3. Search the wiki.
4. Use either of these quick actions:
   - double-click a result to open it as a local webpage
   - add only the rows you want to the save list
5. Give the local archive a file name.
6. Click **Save save list as local archive**.

## Download Entire Wiki workflow

1. Choose a Wikimedia project and language.
2. Open **Download Entire Wiki**.
3. Click **1. Load archive dates**.
4. Highlight a dump date.
5. Click **2. Show whole-archive choices**.
6. Highlight a choice and read the **Step 3 — Review highlighted choice** panel.
7. Tick **I understand this downloads a whole wiki archive, not just the selected page.**
8. Click **4. Start whole-archive download**.
9. Confirm the final dialog.
10. Wait for downloading and indexing to finish.
11. The finished archive appears in **Archive Library**.

Important note: large whole-archive downloads are added to the library **after** the files finish downloading **and** the page index finishes building.

## Archive browsing workflow

1. Highlight an archive in **Archive Library**.
2. Double-click it, or click **Load highlighted archive pages**.
3. Use the **Page filter** on the right if the archive is large.
4. Double-click any page row to open it as a local wiki-style webpage.

## Supported archive formats

Single-file archives:

- `.xml`
- `.xml.bz2`
- `.xml.gz`

Whole wiki downloads can also be stored as a **multi-file managed archive folder** when Wikimedia publishes the dump as split parts.

## What the app remembers

- which archives were downloaded or imported
- when each archive was **added**
- when each archive was **opened**
- when each archive was **checked for updates**
- whether full dump files for a given dump date already exist in the library
- whether searched pages were already saved in another bundle

## Files in this package

- `app.py` — GUI entry point
- `core.py` — dump browsing, XML parsing, caching, page export, and local webpage generation
- `assets/app_icon.png` — neutral app icon
- `assets/app_icon.ico` — Windows icon
- `run_windows.bat` — quick launcher for Windows systems with Python installed
- `build_windows_exe.bat` — PyInstaller build helper for Windows
- `installer/windows/WikiArchiveNavigator.iss` — Inno Setup installer script
- `QUICK-WALKTHROUGH.md` — short step-by-step guide

## Run from source

Python 3.11+ is recommended.

```bash
python app.py
```

Open a file immediately:

```bash
python app.py --open path/to/archive.xml
```

Parser smoke test:

```bash
python app.py --smoke-test path/to/archive.xml path/to/archive.xml.bz2
```

## Portable Python build

You can turn the folder into a `.pyz` archive or use the included `.pyz` file if one is provided in the package.

## Build a Windows EXE

Run:

```bat
build_windows_exe.bat
```

That produces:

```text
dist\WikiArchiveNavigator.exe
```

Then use:

```text
installer\windows\WikiArchiveNavigator.iss
```

to build a Windows installer with Inno Setup.

## App data folder

The app stores local data here:

```text
~/.wiki_archive_navigator
```

Inside that folder:

- `archives/` — managed archive downloads and copies
- `page_cache/` — cached page reads
- `web_preview/` — local webpage preview files
- `state.json` — settings and library memory

## Practical notes

- Some Wikimedia dumps are published as **split parts**. This app groups those parts into one easier whole-archive choice.
- Removing a library entry does **not** delete the original file or folder from disk.
- Imported archives can be browsed even if they are stored outside the managed archive folder.
- Full dump update checks compare the archive's stored dump date with the latest dated dump directory.

Windows launcher and builder updated to auto-detect Python installs and avoid the Microsoft Store alias.
