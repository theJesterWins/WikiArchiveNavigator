@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

call :find_python
if not defined PYTHON_EXE goto :no_python

echo Using Python:
echo   !PYTHON_EXE!
echo.
"!PYTHON_EXE!" -c "import sys; print(sys.version)" || goto :error

echo Installing PyInstaller...
"!PYTHON_EXE!" -m pip install --upgrade pip pyinstaller || goto :error

echo.
echo Building Wiki Archive Navigator for Windows...
"!PYTHON_EXE!" -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name WikiArchiveNavigator ^
  --icon assets\app_icon.ico ^
  --add-data "assets;assets" ^
  app.py || goto :error

echo.
echo Build complete.
echo Your Windows executable should be here:
echo   dist\WikiArchiveNavigator.exe
echo.
pause
exit /b 0

:find_python
set "PYTHON_EXE="

REM Try the Python launcher first
where py >nul 2>nul
if not errorlevel 1 (
  for /f "usebackq delims=" %%I in (`py -3 -c "import sys; print(sys.executable)" 2^>nul`) do set "PYTHON_EXE=%%I"
  if defined PYTHON_EXE goto :eof
)

REM Try python on PATH, but ignore the Windows Store alias
for /f "delims=" %%I in ('where python 2^>nul') do (
  echo %%~fI | find /i "WindowsApps" >nul
  if errorlevel 1 (
    set "PYTHON_EXE=%%~fI"
    goto :eof
  )
)

REM Try common install locations
for %%R in ("%LocalAppData%\Programs\Python" "%ProgramFiles%\Python" "%ProgramFiles(x86)%\Python") do (
  if exist "%%~R" (
    for /f "delims=" %%I in ('dir /b /ad /o-n "%%~R\Python*" 2^>nul') do (
      if exist "%%~R\%%~I\python.exe" (
        set "PYTHON_EXE=%%~R\%%~I\python.exe"
        goto :eof
      )
    )
  )
)

goto :eof

:no_python
echo Could not find a usable Python installation.
echo.
echo Windows is probably pointing the command ^"python^" to the Microsoft Store alias.
echo.
echo Try one of these:
echo   1. Install Python from python.org and tick ^"Add Python to PATH^"
echo   2. Turn off Settings ^> Apps ^> Advanced app settings ^> App execution aliases
ECHO      and disable python.exe and python3.exe aliases
ECHO   3. Edit this file and set PYTHON_EXE to the full path of your python.exe
ECHO.
pause
exit /b 1

:error
echo.
echo Build failed.
pause
exit /b 1
