@echo off
setlocal
cd /d "%~dp0"

call :find_python || goto :error

echo Using: %PY_CMD%
echo Installing PyInstaller...
%PY_CMD% -m pip install --upgrade pip pyinstaller || goto :error

echo Building Wiki Archive Navigator for Windows...
%PY_CMD% -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name WikiArchiveNavigator ^
  --icon assets\app_icon.ico ^
  --add-data "assets;assets" ^
  app.py || goto :error

echo.
echo Build complete.
echo Your Windows executable should be here:
echo   dist\WikiArchiveNavigator.exe
echo.
pause
exit /b 0

:find_python
where py >nul 2>nul
if not errorlevel 1 (
    set "PY_CMD=py -3"
    exit /b 0
)

where python >nul 2>nul
if not errorlevel 1 (
    set "PY_CMD=python"
    exit /b 0
)

echo.
echo Python 3 was not found.
echo.
echo This package includes the app source and build files, but not the Python interpreter itself.
echo Install Python 3 from python.org and tick "Add Python to PATH".
echo If Python is already installed, try turning off the Microsoft Store aliases for python.exe and python3.exe.
exit /b 1

:error
echo.
echo Build failed.
pause
exit /b 1
