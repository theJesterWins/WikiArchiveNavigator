from __future__ import annotations

import argparse
import os
import queue
import shutil
import subprocess
import sys
import threading
import webbrowser
from datetime import datetime
from pathlib import Path

APP_DIR = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
ASSETS_DIR = APP_DIR / "assets"
ICON_PNG = ASSETS_DIR / "app_icon.png"
ICON_ICO = ASSETS_DIR / "app_icon.ico"
from typing import Any, Callable, Optional

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText

from core import (
    APP_NAME,
    APP_VERSION,
    ARCHIVE_HOME,
    DUMP_CHOICES,
    PREVIEW_HOME,
    BundleEntry,
    DumpFile,
    DumpOption,
    DumpRun,
    FIXED_PROJECTS,
    LANGUAGE_PROJECTS,
    LoadedArchive,
    PageIndexEntry,
    PageRecord,
    QueueItem,
    SearchResult,
    SiteInfo,
    StateStore,
    WikiApiClient,
    WikiArchiveError,
    WikiDumpClient,
    build_archive_index,
    build_archive_index_many,
    build_bundle_entry,
    build_local_page_html,
    bundle_kind_label,
    bundle_path_exists,
    bundle_source_paths,
    bundle_summary_text,
    detect_bundle_type,
    dump_option_label,
    exception_text,
    extract_page_from_archive,
    extract_page_from_archive_many,
    extract_wikilinks,
    file_fingerprint,
    format_dump_run,
    grouped_dump_options,
    is_managed_copy,
    load_cached_page,
    loaded_archive_from_bundle,
    now_utc_iso,
    page_summary_text,
    page_xml_snippet,
    preview_html_filename,
    project_api_url,
    render_plain_text,
    safe_display_date,
    safe_local_time,
    sanitize_filename,
    save_bundle_file,
    save_cached_page,
    site_page_url,
    unique_bundle_name,
)

SAVE_FORMATS = [
    "MediaWiki XML (.xml)",
    "Compressed MediaWiki XML (.xml.bz2)",
]


class ArchiveReaderApp(tk.Tk):
    def __init__(self, open_path: Optional[Path] = None) -> None:
        super().__init__()
        self.title(f"{APP_NAME} {APP_VERSION}")
        self.minsize(1220, 760)
        self._icon_image = None
        self._load_window_icon()

        self.state_store = StateStore()
        self.api_client = WikiApiClient(logger=self._thread_safe_log)
        self.dump_client = WikiDumpClient(logger=self._thread_safe_log)
        self.worker_queue: "queue.Queue[tuple[str, Any]]" = queue.Queue()

        self.search_results_by_iid: dict[str, SearchResult] = {}
        self.queue_items_by_iid: dict[str, QueueItem] = {}
        self.dump_runs_by_iid: dict[str, DumpRun] = {}
        self.dump_options_by_iid: dict[str, DumpOption] = {}
        self.loaded_archives: dict[str, LoadedArchive] = {}
        self.selection_context: tuple[str, str] | None = None
        self.active_tasks = 0

        self.current_bundle: Optional[BundleEntry] = None
        self.current_archive: Optional[LoadedArchive] = None
        self.current_page_title: str = ""

        self._build_variables()
        self._build_styles()
        self._build_ui()
        self._load_settings()
        self._refresh_download_index()
        self.refresh_bundle_tree()
        self._update_action_buttons()

        self.after(150, self._process_worker_queue)
        self.after(250, self._set_initial_pane_positions)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        if open_path:
            self.after(300, lambda: self.import_archive_dialog(open_path))

    # -----------------------------
    # Tk setup
    # -----------------------------
    def _load_window_icon(self) -> None:
        try:
            if ICON_PNG.exists():
                self._icon_image = tk.PhotoImage(file=str(ICON_PNG))
                self.iconphoto(True, self._icon_image)
            elif sys.platform.startswith("win") and ICON_ICO.exists():
                self.iconbitmap(str(ICON_ICO))
        except Exception:
            self._icon_image = None

    def _set_initial_pane_positions(self) -> None:
        try:
            self.update_idletasks()
            self.left_pane.sashpos(0, 320)
        except Exception:
            pass

    def _build_variables(self) -> None:
        self.status_var = tk.StringVar(value="Ready.")
        self.archive_folder_var = tk.StringVar(value=str(ARCHIVE_HOME))
        self.project_var = tk.StringVar(value="Abstract Wikipedia")
        self.language_var = tk.StringVar(value="en")
        self.api_preview_var = tk.StringVar(value="")
        self.dump_dbname_var = tk.StringVar(value="")
        self.dump_choice_var = tk.StringVar(value=self.state_store.get_setting("dump_choice", DUMP_CHOICES["recommended_reading"]))
        self.dump_summary_var = tk.StringVar(value="Start on Search & Save Pages, or use Download Entire Wiki when you truly want a full archive.")
        self.dump_confirm_var = tk.BooleanVar(value=False)
        self.search_var = tk.StringVar()
        self.bundle_name_var = tk.StringVar(value=self._default_bundle_name())
        self.save_format_var = tk.StringVar(value=SAVE_FORMATS[0])

        self.search_summary_var = tk.StringVar(value="Search a wiki and queue only the pages you want.")
        self.queue_summary_var = tk.StringVar(value="Save list is empty.")

        self.archive_pages_filter_var = tk.StringVar(value="")
        self.archive_pages_status_var = tk.StringVar(value="Select an archive from the library to browse its pages.")
        self.archive_pages_by_iid: dict[str, PageIndexEntry] = {}
        self.archive_filter_after_id: Optional[str] = None

    def _build_styles(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("TkDefaultFont", 15, "bold"))
        style.configure("Subtitle.TLabel", foreground="#4f5b66")
        style.configure("Panel.TLabelframe", padding=8)
        style.configure("Panel.TLabelframe.Label", font=("TkDefaultFont", 10, "bold"))
        style.configure("Action.TButton", padding=(10, 7))
        style.configure("Muted.TLabel", foreground="#5a6670")
        style.configure("Status.TLabel", foreground="#33404a")

    def _build_ui(self) -> None:
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        header = ttk.Frame(self, padding=(12, 10, 12, 4))
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(0, weight=1)
        ttk.Label(header, text=APP_NAME, style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            header,
            text="Wikimedia archive browser for downloading full archives, saving selected pages, and opening local wiki-style webpages.",
            style="Subtitle.TLabel",
        ).grid(row=1, column=0, sticky="w", pady=(2, 0))

        main = ttk.Frame(self, padding=(12, 4, 12, 8))
        main.grid(row=1, column=0, sticky="nsew")
        main.columnconfigure(0, weight=1)
        main.rowconfigure(0, weight=1)

        layout = ttk.Frame(main)
        layout.grid(row=0, column=0, sticky="nsew")
        layout.columnconfigure(0, weight=3)
        layout.columnconfigure(2, weight=0)
        layout.columnconfigure(4, weight=2)
        layout.rowconfigure(0, weight=1)

        self.left_pane = ttk.Panedwindow(layout, orient=tk.VERTICAL)
        self.left_pane.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        self.archive_frame = ttk.LabelFrame(self.left_pane, text="Archive Library", style="Panel.TLabelframe")
        self.download_frame = ttk.LabelFrame(self.left_pane, text="Wiki Download & Storage", style="Panel.TLabelframe")
        self.left_pane.add(self.archive_frame, weight=1)
        self.left_pane.add(self.download_frame, weight=1)

        self._build_archive_panel(self.archive_frame)
        self._build_download_panel(self.download_frame)

        self.action_frame = ttk.LabelFrame(layout, text="Buttons in Between", style="Panel.TLabelframe")
        self.action_frame.grid(row=0, column=2, sticky="ns", padx=(0, 10))
        self._build_action_panel(self.action_frame)

        self.page_browser_frame = ttk.LabelFrame(layout, text="Archive Pages", style="Panel.TLabelframe")
        self.page_browser_frame.grid(row=0, column=4, sticky="nsew")
        self._build_page_browser_panel(self.page_browser_frame)

        status = ttk.Frame(self, padding=(12, 0, 12, 10))
        status.grid(row=2, column=0, sticky="ew")
        status.columnconfigure(0, weight=1)
        ttk.Label(status, textvariable=self.status_var, style="Status.TLabel").grid(row=0, column=0, sticky="w")
        self.progressbar = ttk.Progressbar(status, mode="indeterminate", length=180)
        self.progressbar.grid(row=0, column=1, sticky="e", padx=(12, 0))

    def _build_archive_panel(self, parent: ttk.LabelFrame) -> None:
        parent.columnconfigure(1, weight=1)
        parent.rowconfigure(2, weight=1)

        ttk.Label(parent, text="Managed archive folder:").grid(row=0, column=0, sticky="w")
        folder_entry = ttk.Entry(parent, textvariable=self.archive_folder_var)
        folder_entry.grid(row=0, column=1, sticky="ew", padx=(8, 8))
        ttk.Button(parent, text="Browse…", command=self.choose_archive_folder).grid(row=0, column=2, sticky="ew")

        button_row = ttk.Frame(parent)
        button_row.grid(row=1, column=0, columnspan=3, sticky="ew", pady=(8, 8))
        ttk.Button(button_row, text="Import XML / XML.BZ2 / XML.GZ…", command=lambda: self.import_archive_dialog()).pack(side=tk.LEFT)
        ttk.Button(button_row, text="Refresh library", command=self.refresh_bundle_tree).pack(side=tk.LEFT, padx=(8, 0))

        tree_container = ttk.Frame(parent)
        tree_container.grid(row=2, column=0, columnspan=3, sticky="nsew")
        tree_container.columnconfigure(0, weight=1)
        tree_container.rowconfigure(0, weight=1)

        columns = ("name", "kind", "site", "pages", "revisions", "added", "opened", "updates", "managed")
        self.bundle_tree = ttk.Treeview(tree_container, columns=columns, show="headings", selectmode="browse")
        headings = {
            "name": "Archive",
            "kind": "Type",
            "site": "Wiki",
            "pages": "Pages",
            "revisions": "Revisions",
            "added": "Added",
            "opened": "Opened",
            "updates": "Updates",
            "managed": "Stored",
        }
        widths = {
            "name": 230,
            "kind": 110,
            "site": 140,
            "pages": 70,
            "revisions": 80,
            "added": 140,
            "opened": 140,
            "updates": 70,
            "managed": 70,
        }
        for column in columns:
            self.bundle_tree.heading(column, text=headings[column])
            self.bundle_tree.column(column, width=widths[column], anchor=(tk.W if column in {"name", "site"} else tk.CENTER))
        self.bundle_tree.grid(row=0, column=0, sticky="nsew")
        bundle_scroll_y = ttk.Scrollbar(tree_container, orient=tk.VERTICAL, command=self.bundle_tree.yview)
        bundle_scroll_y.grid(row=0, column=1, sticky="ns")
        bundle_scroll_x = ttk.Scrollbar(tree_container, orient=tk.HORIZONTAL, command=self.bundle_tree.xview)
        bundle_scroll_x.grid(row=1, column=0, sticky="ew")
        self.bundle_tree.configure(yscrollcommand=bundle_scroll_y.set, xscrollcommand=bundle_scroll_x.set)
        self.bundle_tree.bind("<<TreeviewSelect>>", self._on_bundle_tree_select)
        self.bundle_tree.bind("<Double-1>", lambda _event: self.open_selected_archive())


    def _build_download_panel(self, parent: ttk.LabelFrame) -> None:
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(2, weight=1)

        chooser = ttk.Frame(parent)
        chooser.grid(row=0, column=0, sticky="ew")
        for column in range(4):
            chooser.columnconfigure(column, weight=(1 if column in {1, 3} else 0))

        ttk.Label(chooser, text="Wikimedia project:").grid(row=0, column=0, sticky="w")
        project_values = self.api_projects_fixed_first()
        self.project_combo = ttk.Combobox(chooser, textvariable=self.project_var, values=project_values, state="readonly")
        self.project_combo.grid(row=0, column=1, sticky="ew", padx=(8, 12))
        self.project_combo.bind("<<ComboboxSelected>>", lambda _event: self._update_api_preview())

        ttk.Label(chooser, text="Language code:").grid(row=0, column=2, sticky="w")
        self.language_entry = ttk.Entry(chooser, textvariable=self.language_var, width=10)
        self.language_entry.grid(row=0, column=3, sticky="w")

        ttk.Label(chooser, text="API endpoint:", style="Muted.TLabel").grid(row=1, column=0, sticky="w", pady=(6, 0))
        ttk.Label(chooser, textvariable=self.api_preview_var, style="Muted.TLabel").grid(
            row=1,
            column=1,
            columnspan=3,
            sticky="w",
            pady=(6, 0),
        )

        ttk.Label(
            parent,
            text="Start on Search & Save Pages if you only want specific topics. Use Download Entire Wiki only when you truly want a whole archive.",
            style="Muted.TLabel",
            wraplength=760,
            justify=tk.LEFT,
        ).grid(row=1, column=0, sticky="w", pady=(8, 8))

        notebook = ttk.Notebook(parent)
        notebook.grid(row=2, column=0, sticky="nsew")
        self.collection_notebook = notebook

        selected_tab = ttk.Frame(notebook, padding=6)
        full_tab = ttk.Frame(notebook, padding=6)
        activity_tab = ttk.Frame(notebook, padding=6)

        self.selected_pages_tab = selected_tab
        self.full_archive_tab = full_tab
        self.activity_tab = activity_tab

        notebook.add(selected_tab, text="Search & Save Pages")
        notebook.add(full_tab, text="Download Entire Wiki")
        notebook.add(activity_tab, text="Activity & Help")

        self._build_selected_pages_tab(selected_tab)
        self._build_full_archive_tab(full_tab)
        self._build_activity_tab(activity_tab)

        notebook.select(selected_tab)
        self._update_api_preview()

    def _build_full_archive_tab(self, parent: ttk.Frame) -> None:
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(4, weight=1)

        ttk.Label(
            parent,
            text="Use this tab only when you want a whole wiki archive. Many whole-archive downloads are large, so Search & Save Pages is the lighter option.",
            style="Muted.TLabel",
            wraplength=760,
            justify=tk.LEFT,
        ).grid(row=0, column=0, sticky="w", pady=(0, 8))

        controls = ttk.Frame(parent)
        controls.grid(row=1, column=0, sticky="ew")
        controls.columnconfigure(1, weight=1)
        controls.columnconfigure(3, weight=1)

        ttk.Label(controls, text="Wiki database name:").grid(row=0, column=0, sticky="w")
        ttk.Label(controls, textvariable=self.dump_dbname_var).grid(row=0, column=1, sticky="w", padx=(8, 12))
        ttk.Label(controls, text="Preferred whole-archive choice:").grid(row=0, column=2, sticky="w")
        self.dump_choice_combo = ttk.Combobox(
            controls,
            textvariable=self.dump_choice_var,
            values=list(DUMP_CHOICES.values()),
            state="readonly",
            width=32,
        )
        self.dump_choice_combo.grid(row=0, column=3, sticky="w", padx=(8, 0))
        self.dump_choice_combo.bind("<<ComboboxSelected>>", lambda _event: self._on_dump_choice_changed())

        button_row = ttk.Frame(parent)
        button_row.grid(row=2, column=0, sticky="ew", pady=(8, 8))
        ttk.Button(button_row, text="1. Load archive dates", command=self.load_dump_runs).pack(side=tk.LEFT)
        ttk.Button(button_row, text="2. Show whole-archive choices", command=self.load_selected_dump_files).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Button(button_row, text="Use recommended choice", command=self.download_recommended_dump).pack(side=tk.LEFT, padx=(8, 0))

        ttk.Label(parent, textvariable=self.dump_summary_var, style="Muted.TLabel", wraplength=760, justify=tk.LEFT).grid(
            row=3,
            column=0,
            sticky="w",
            pady=(0, 8),
        )

        paned = ttk.Panedwindow(parent, orient=tk.HORIZONTAL)
        paned.grid(row=4, column=0, sticky="nsew")

        runs_frame = ttk.Frame(paned)
        runs_frame.columnconfigure(0, weight=1)
        runs_frame.rowconfigure(2, weight=1)

        options_frame = ttk.Frame(paned)
        options_frame.columnconfigure(0, weight=1)
        options_frame.rowconfigure(2, weight=1)

        paned.add(runs_frame, weight=1)
        paned.add(options_frame, weight=2)

        ttk.Label(runs_frame, text="Step 1 — Archive dates", style="Panel.TLabelframe.Label").grid(row=0, column=0, sticky="w", pady=(0, 6))
        ttk.Label(
            runs_frame,
            text="Highlight a dump date, then click Step 2 to list whole-archive choices for that date.",
            style="Muted.TLabel",
            wraplength=260,
            justify=tk.LEFT,
        ).grid(row=1, column=0, sticky="w", pady=(0, 6))
        run_columns = ("run", "listed", "downloaded")
        self.dump_runs_tree = ttk.Treeview(runs_frame, columns=run_columns, show="headings", selectmode="browse")
        run_headings = {
            "run": "Archive date",
            "listed": "Listed",
            "downloaded": "In library",
        }
        run_widths = {"run": 120, "listed": 150, "downloaded": 90}
        for column in run_columns:
            self.dump_runs_tree.heading(column, text=run_headings[column])
            self.dump_runs_tree.column(column, width=run_widths[column], anchor=(tk.W if column == "run" else tk.CENTER))
        self.dump_runs_tree.grid(row=2, column=0, sticky="nsew")
        run_scroll = ttk.Scrollbar(runs_frame, orient=tk.VERTICAL, command=self.dump_runs_tree.yview)
        run_scroll.grid(row=2, column=1, sticky="ns")
        self.dump_runs_tree.configure(yscrollcommand=run_scroll.set)
        self.dump_runs_tree.bind("<<TreeviewSelect>>", self._on_dump_run_selected)
        self.dump_runs_tree.bind("<Double-1>", lambda _event: self.load_selected_dump_files())

        ttk.Label(options_frame, text="Step 2 — Whole-archive choices for the highlighted date", style="Panel.TLabelframe.Label").grid(row=0, column=0, sticky="w", pady=(0, 6))
        ttk.Label(
            options_frame,
            text="Only full archive choices are shown here. Tiny helper files are hidden. Highlight a choice to review it before anything downloads.",
            style="Muted.TLabel",
            wraplength=520,
            justify=tk.LEFT,
        ).grid(row=1, column=0, sticky="w", pady=(0, 6))
        option_columns = ("option", "scope", "type", "files", "uploaded", "size", "downloaded")
        self.dump_options_tree = ttk.Treeview(options_frame, columns=option_columns, show="headings", selectmode="browse")
        option_headings = {
            "option": "Whole-archive choice",
            "scope": "Scope",
            "type": "Type",
            "files": "Files",
            "uploaded": "Uploaded",
            "size": "Total size",
            "downloaded": "In library",
        }
        option_widths = {
            "option": 290,
            "scope": 170,
            "type": 110,
            "files": 70,
            "uploaded": 150,
            "size": 100,
            "downloaded": 80,
        }
        for column in option_columns:
            self.dump_options_tree.heading(column, text=option_headings[column])
            self.dump_options_tree.column(column, width=option_widths[column], anchor=(tk.W if column in {"option", "scope"} else tk.CENTER))
        self.dump_options_tree.grid(row=2, column=0, sticky="nsew")
        option_scroll_y = ttk.Scrollbar(options_frame, orient=tk.VERTICAL, command=self.dump_options_tree.yview)
        option_scroll_y.grid(row=2, column=1, sticky="ns")
        option_scroll_x = ttk.Scrollbar(options_frame, orient=tk.HORIZONTAL, command=self.dump_options_tree.xview)
        option_scroll_x.grid(row=3, column=0, sticky="ew")
        self.dump_options_tree.configure(yscrollcommand=option_scroll_y.set, xscrollcommand=option_scroll_x.set)
        self.dump_options_tree.bind("<<TreeviewSelect>>", self._on_dump_option_selected)

        review_frame = ttk.LabelFrame(options_frame, text="Step 3 — Review highlighted choice", style="Panel.TLabelframe")
        review_frame.grid(row=4, column=0, columnspan=2, sticky="nsew", pady=(10, 0))
        review_frame.columnconfigure(0, weight=1)
        review_frame.rowconfigure(1, weight=1)

        ttk.Label(
            review_frame,
            text="Nothing starts downloading until you tick the confirmation box and click Start whole-archive download.",
            style="Muted.TLabel",
            wraplength=520,
            justify=tk.LEFT,
        ).grid(row=0, column=0, sticky="w", pady=(0, 6))

        self.dump_review_text = ScrolledText(review_frame, height=10, wrap=tk.WORD)
        self.dump_review_text.grid(row=1, column=0, sticky="nsew")
        self.dump_review_text.configure(state=tk.DISABLED)

        self.dump_confirm_check = ttk.Checkbutton(
            review_frame,
            text="I understand this downloads a whole wiki archive, not just the selected page.",
            variable=self.dump_confirm_var,
            command=self._update_dump_download_state,
        )
        self.dump_confirm_check.grid(row=2, column=0, sticky="w", pady=(8, 0))

        download_row = ttk.Frame(review_frame)
        download_row.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        self.dump_download_button = ttk.Button(
            download_row,
            text="4. Start whole-archive download",
            command=self.download_selected_dump_option,
        )
        self.dump_download_button.pack(side=tk.LEFT)

        self._set_dump_review("Highlight a whole-archive choice to review it here.")
        self._update_dump_download_state()

    def _build_selected_pages_tab(self, parent: ttk.Frame) -> None:
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(0, weight=1)

        pane = ttk.Panedwindow(parent, orient=tk.VERTICAL)
        pane.grid(row=0, column=0, sticky="nsew")

        search_frame = ttk.Frame(pane)
        search_frame.columnconfigure(0, weight=1)
        search_frame.columnconfigure(1, weight=0)
        search_frame.rowconfigure(2, weight=1)
        queue_frame = ttk.Frame(pane)
        queue_frame.columnconfigure(0, weight=1)
        queue_frame.rowconfigure(1, weight=1)
        pane.add(search_frame, weight=3)
        pane.add(queue_frame, weight=2)

        ttk.Label(search_frame, text="Search and save individual pages:").grid(row=0, column=0, sticky="w")
        search_entry_row = ttk.Frame(search_frame)
        search_entry_row.grid(row=1, column=0, sticky="ew", pady=(6, 0))
        search_entry_row.columnconfigure(0, weight=1)
        self.search_entry = ttk.Entry(search_entry_row, textvariable=self.search_var)
        self.search_entry.grid(row=0, column=0, sticky="ew")
        self.search_entry.bind("<Return>", lambda _event: self.search_current_wiki())
        ttk.Button(search_entry_row, text="Search wiki", command=self.search_current_wiki).grid(row=0, column=1, sticky="ew", padx=(8, 0))

        ttk.Label(search_frame, textvariable=self.search_summary_var, style="Muted.TLabel", wraplength=760, justify=tk.LEFT).grid(
            row=2,
            column=0,
            sticky="w",
            pady=(6, 6),
        )
        ttk.Label(
            search_frame,
            text="Tip: double-click a result to open it as a local webpage, or highlight results and add only the ones you want to the save list.",
            style="Muted.TLabel",
        ).grid(row=3, column=0, sticky="w", pady=(0, 6))

        results_container = ttk.Frame(search_frame)
        results_container.grid(row=4, column=0, sticky="nsew")
        results_container.columnconfigure(0, weight=1)
        results_container.rowconfigure(0, weight=1)
        search_frame.rowconfigure(4, weight=1)

        columns = ("title", "namespace", "edited", "downloaded", "downloaded_on", "snippet")
        self.search_tree = ttk.Treeview(results_container, columns=columns, show="headings", selectmode="extended")
        headings = {
            "title": "Title",
            "namespace": "Namespace",
            "edited": "Latest edit",
            "downloaded": "Downloaded",
            "downloaded_on": "Downloaded on",
            "snippet": "Snippet",
        }
        widths = {
            "title": 220,
            "namespace": 100,
            "edited": 130,
            "downloaded": 80,
            "downloaded_on": 140,
            "snippet": 260,
        }
        for column in columns:
            self.search_tree.heading(column, text=headings[column])
            self.search_tree.column(column, width=widths[column], anchor=(tk.W if column in {"title", "snippet", "namespace"} else tk.CENTER))
        self.search_tree.grid(row=0, column=0, sticky="nsew")
        search_scroll_y = ttk.Scrollbar(results_container, orient=tk.VERTICAL, command=self.search_tree.yview)
        search_scroll_y.grid(row=0, column=1, sticky="ns")
        search_scroll_x = ttk.Scrollbar(results_container, orient=tk.HORIZONTAL, command=self.search_tree.xview)
        search_scroll_x.grid(row=1, column=0, sticky="ew")
        self.search_tree.configure(yscrollcommand=search_scroll_y.set, xscrollcommand=search_scroll_x.set)
        self.search_tree.bind("<<TreeviewSelect>>", self._on_search_tree_select)
        self.search_tree.bind("<Double-1>", lambda _event: self.open_selected_context_as_webpage())

        search_buttons = ttk.Frame(search_frame)
        search_buttons.grid(row=5, column=0, sticky="ew", pady=(8, 0))
        ttk.Button(search_buttons, text="Open highlighted result as webpage", command=self.open_selected_context_as_webpage).pack(side=tk.LEFT)
        ttk.Button(search_buttons, text="Add highlighted result(s)", command=self.add_selected_results_to_queue).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Button(search_buttons, text="Add all shown results", command=self.add_all_results_to_queue).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Button(search_buttons, text="Add links from highlighted", command=self.expand_selected_results_to_queue).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Button(search_buttons, text="Clear search results", command=self.clear_search_results).pack(side=tk.LEFT, padx=(8, 0))

        ttk.Label(queue_frame, textvariable=self.queue_summary_var, style="Muted.TLabel", wraplength=760, justify=tk.LEFT).grid(row=0, column=0, sticky="w")

        queue_columns = ("title", "namespace", "site", "edited", "downloaded", "downloaded_on")
        self.queue_tree = ttk.Treeview(queue_frame, columns=queue_columns, show="headings", selectmode="extended")
        queue_headings = {
            "title": "Title",
            "namespace": "Namespace",
            "site": "Wiki",
            "edited": "Latest edit",
            "downloaded": "Downloaded",
            "downloaded_on": "Downloaded on",
        }
        queue_widths = {
            "title": 250,
            "namespace": 110,
            "site": 150,
            "edited": 130,
            "downloaded": 80,
            "downloaded_on": 140,
        }
        for column in queue_columns:
            self.queue_tree.heading(column, text=queue_headings[column])
            self.queue_tree.column(column, width=queue_widths[column], anchor=(tk.W if column in {"title", "namespace", "site"} else tk.CENTER))
        self.queue_tree.grid(row=1, column=0, sticky="nsew")
        queue_scroll_y = ttk.Scrollbar(queue_frame, orient=tk.VERTICAL, command=self.queue_tree.yview)
        queue_scroll_y.grid(row=1, column=1, sticky="ns")
        queue_scroll_x = ttk.Scrollbar(queue_frame, orient=tk.HORIZONTAL, command=self.queue_tree.xview)
        queue_scroll_x.grid(row=2, column=0, sticky="ew")
        self.queue_tree.configure(yscrollcommand=queue_scroll_y.set, xscrollcommand=queue_scroll_x.set)
        self.queue_tree.bind("<<TreeviewSelect>>", self._on_queue_tree_select)
        self.queue_tree.bind("<Double-1>", lambda _event: self.open_selected_context_as_webpage())

        form = ttk.Frame(queue_frame)
        form.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        form.columnconfigure(1, weight=1)
        ttk.Label(form, text="Local archive file name:").grid(row=0, column=0, sticky="w")
        ttk.Entry(form, textvariable=self.bundle_name_var).grid(row=0, column=1, sticky="ew", padx=(8, 12))
        ttk.Label(form, text="Save as:").grid(row=0, column=2, sticky="w")
        ttk.Combobox(form, textvariable=self.save_format_var, values=SAVE_FORMATS, state="readonly", width=28).grid(
            row=0,
            column=3,
            sticky="w",
            padx=(8, 12),
        )
        ttk.Button(form, text="Open highlighted page as webpage", command=self.open_selected_context_as_webpage).grid(row=0, column=4, sticky="w")

        queue_buttons = ttk.Frame(queue_frame)
        queue_buttons.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        ttk.Button(queue_buttons, text="Remove highlighted", command=self.remove_selected_queue_items).pack(side=tk.LEFT)
        ttk.Button(queue_buttons, text="Clear save list", command=self.clear_queue).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Button(queue_buttons, text="Save save list as local archive", command=self.download_queue_to_archive).pack(side=tk.LEFT, padx=(8, 0))

    def _build_activity_tab(self, parent: ttk.Frame) -> None:
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(2, weight=1)
        ttk.Label(
            parent,
            text="Quick start: use Full Wiki Archive to download a whole archive, or Selected Pages to search and save only the pages you want.",
            style="Muted.TLabel",
            wraplength=760,
            justify=tk.LEFT,
        ).grid(row=0, column=0, sticky="w")
        ttk.Button(parent, text="Show walkthrough", command=self.show_walkthrough).grid(row=1, column=0, sticky="w", pady=(8, 8))
        self.activity_text = ScrolledText(parent, wrap=tk.WORD, height=10)
        self.activity_text.grid(row=2, column=0, sticky="nsew")
        self.activity_text.insert(tk.END, "Activity log will appear here.\n")
        self.activity_text.configure(state=tk.DISABLED)

    def _build_action_panel(self, parent: ttk.LabelFrame) -> None:
        for row in range(7):
            parent.rowconfigure(row, weight=0)
        parent.columnconfigure(0, weight=1)
        ttk.Label(
            parent,
            text="Use these buttons with the highlighted archive or the highlighted page row on the right.",
            style="Muted.TLabel",
            wraplength=190,
            justify=tk.LEFT,
        ).grid(row=0, column=0, sticky="ew", pady=(0, 12))

        self.open_archive_button = ttk.Button(parent, text="Load highlighted archive pages", style="Action.TButton", command=self.open_selected_archive)
        self.open_archive_button.grid(row=1, column=0, sticky="ew", pady=(0, 8))

        self.preview_button = ttk.Button(parent, text="Open highlighted page as webpage", style="Action.TButton", command=self.open_selected_context_as_webpage)
        self.preview_button.grid(row=2, column=0, sticky="ew", pady=(0, 8))

        self.check_updates_button = ttk.Button(parent, text="Check for updates", style="Action.TButton", command=self.check_selected_bundle_updates)
        self.check_updates_button.grid(row=3, column=0, sticky="ew", pady=(0, 8))

        self.archive_copy_button = ttk.Button(parent, text="Copy archive into library folder", style="Action.TButton", command=self.copy_selected_bundle_into_archive)
        self.archive_copy_button.grid(row=4, column=0, sticky="ew", pady=(0, 8))

        self.open_location_button = ttk.Button(parent, text="Open file location", style="Action.TButton", command=self.open_selected_bundle_location)
        self.open_location_button.grid(row=5, column=0, sticky="ew", pady=(0, 8))

        self.remove_bundle_button = ttk.Button(parent, text="Remove library entry", style="Action.TButton", command=self.remove_selected_bundle_entry)
        self.remove_bundle_button.grid(row=6, column=0, sticky="ew", pady=(0, 8))

        ttk.Button(parent, text="Show walkthrough", command=self.show_walkthrough).grid(row=7, column=0, sticky="ew")

    def _build_page_browser_panel(self, parent: ttk.LabelFrame) -> None:
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(2, weight=1)

        ttk.Label(
            parent,
            textvariable=self.archive_pages_status_var,
            style="Muted.TLabel",
            wraplength=520,
            justify=tk.LEFT,
        ).grid(row=0, column=0, sticky="w", pady=(0, 8))

        filter_row = ttk.Frame(parent)
        filter_row.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        filter_row.columnconfigure(1, weight=1)
        ttk.Label(filter_row, text="Page filter:").grid(row=0, column=0, sticky="w")
        self.archive_filter_entry = ttk.Entry(filter_row, textvariable=self.archive_pages_filter_var)
        self.archive_filter_entry.grid(row=0, column=1, sticky="ew", padx=(8, 8))
        self.archive_filter_entry.bind("<Return>", lambda _event: self.apply_archive_filter())
        self.archive_filter_entry.bind("<KeyRelease>", self._schedule_archive_filter)
        ttk.Button(filter_row, text="Apply", command=self.apply_archive_filter).grid(row=0, column=2, sticky="ew")
        ttk.Button(filter_row, text="Clear", command=self.clear_archive_filter).grid(row=0, column=3, sticky="ew", padx=(8, 0))

        table_frame = ttk.Frame(parent)
        table_frame.grid(row=2, column=0, sticky="nsew")
        table_frame.columnconfigure(0, weight=1)
        table_frame.rowconfigure(0, weight=1)

        columns = ("title", "namespace", "edited", "revisions")
        self.archive_pages_tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        headings = {
            "title": "Title",
            "namespace": "Namespace",
            "edited": "Latest edit",
            "revisions": "Revisions",
        }
        widths = {
            "title": 270,
            "namespace": 110,
            "edited": 145,
            "revisions": 90,
        }
        for column in columns:
            self.archive_pages_tree.heading(column, text=headings[column])
            self.archive_pages_tree.column(column, width=widths[column], anchor=(tk.W if column in {"title", "namespace"} else tk.CENTER))
        self.archive_pages_tree.grid(row=0, column=0, sticky="nsew")
        scroll_y = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.archive_pages_tree.yview)
        scroll_y.grid(row=0, column=1, sticky="ns")
        scroll_x = ttk.Scrollbar(table_frame, orient=tk.HORIZONTAL, command=self.archive_pages_tree.xview)
        scroll_x.grid(row=1, column=0, sticky="ew")
        self.archive_pages_tree.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        self.archive_pages_tree.bind("<<TreeviewSelect>>", self._on_archive_page_tree_select)
        self.archive_pages_tree.bind("<Double-1>", lambda _event: self.open_selected_context_as_webpage())

        ttk.Label(
            parent,
            text="Double-click a page row to open a local wiki-style webpage. Large archives show the first 1000 matches until you narrow the filter.",
            style="Muted.TLabel",
            wraplength=520,
            justify=tk.LEFT,
        ).grid(row=3, column=0, sticky="w", pady=(8, 0))

    def _namespace_label(self, siteinfo: SiteInfo, namespace: int) -> str:
        label = siteinfo.namespaces.get(namespace, "")
        return label or "Article"

    def _schedule_archive_filter(self, _event: Any = None) -> None:
        if self.archive_filter_after_id:
            try:
                self.after_cancel(self.archive_filter_after_id)
            except Exception:
                pass
        self.archive_filter_after_id = self.after(250, self.apply_archive_filter)

    def clear_archive_filter(self) -> None:
        self.archive_pages_filter_var.set("")
        self.apply_archive_filter()

    def apply_archive_filter(self, select_title: Optional[str] = None) -> None:
        if self.archive_filter_after_id:
            try:
                self.after_cancel(self.archive_filter_after_id)
            except Exception:
                pass
            self.archive_filter_after_id = None

        if not hasattr(self, "archive_pages_tree"):
            return

        for item in self.archive_pages_tree.get_children():
            self.archive_pages_tree.delete(item)
        self.archive_pages_by_iid.clear()

        if self.current_archive is None:
            self.archive_pages_status_var.set("Select an archive from the library to browse its pages.")
            self.current_page_title = ""
            self.selection_context = None
            self._update_action_buttons()
            return

        pages = list(self.current_archive.page_index)
        query = self.archive_pages_filter_var.get().strip().lower()

        def include(entry: PageIndexEntry) -> bool:
            if not query:
                return True
            namespace_label = self._namespace_label(self.current_archive.siteinfo, entry.namespace).lower()
            return query in entry.title.lower() or query in namespace_label

        matches = [entry for entry in pages if include(entry)]
        matches.sort(key=lambda entry: (entry.title.lower(), self._namespace_label(self.current_archive.siteinfo, entry.namespace).lower()))
        limit = 1000
        shown = matches[:limit]

        for index, entry in enumerate(shown, start=1):
            iid = f"archive_page_{index}"
            self.archive_pages_by_iid[iid] = entry
            self.archive_pages_tree.insert(
                "",
                tk.END,
                iid=iid,
                values=(
                    entry.title,
                    self._namespace_label(self.current_archive.siteinfo, entry.namespace),
                    safe_display_date(entry.latest_timestamp),
                    entry.revision_count,
                ),
            )

        archive_name = self.current_bundle.name if self.current_bundle else (self.current_archive.siteinfo.sitename or self.current_archive.title)
        if not pages:
            status = f"{archive_name} has no indexed pages."
        elif query:
            status = f"{archive_name} — showing {len(shown)} of {len(matches)} matching pages ({len(pages)} total). Double-click a row to open it as a local webpage."
            if len(matches) > limit:
                status += " Narrow the filter to see the rest."
        else:
            status = f"{archive_name} — showing {len(shown)} of {len(pages)} pages. Double-click a row to open it as a local webpage."
            if len(pages) > limit:
                status += " Use the page filter to narrow large archives."
        self.archive_pages_status_var.set(status)

        target_title = select_title or self.current_page_title
        target_iid = None
        if target_title:
            for iid, entry in self.archive_pages_by_iid.items():
                if entry.title == target_title:
                    target_iid = iid
                    break
        if target_iid is None and shown:
            target_iid = next(iter(self.archive_pages_by_iid.keys()))

        if target_iid:
            self.archive_pages_tree.selection_set(target_iid)
            self.archive_pages_tree.focus(target_iid)
            self.archive_pages_tree.see(target_iid)
            self._on_archive_page_tree_select()
        else:
            self.current_page_title = ""
            if self.current_bundle is not None:
                self.selection_context = ("bundle", self.current_bundle.entry_id)
            else:
                self.selection_context = None
            self._update_action_buttons()

    def _on_archive_page_tree_select(self, _event: Any = None) -> None:
        selection = self.archive_pages_tree.selection() if hasattr(self, "archive_pages_tree") else ()
        if selection:
            iid = selection[0]
            entry = self.archive_pages_by_iid.get(iid)
            if entry is not None:
                self.current_page_title = entry.title
                self.selection_context = ("archive_page", iid)
        elif self.current_bundle is not None:
            self.selection_context = ("bundle", self.current_bundle.entry_id)
            self.current_page_title = ""
        else:
            self.selection_context = None
            self.current_page_title = ""
        self._update_action_buttons()

    def _build_revisions_tab(self, parent: ttk.Frame) -> None:
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(0, weight=1)
        pane = ttk.Panedwindow(parent, orient=tk.VERTICAL)
        pane.grid(row=0, column=0, sticky="nsew")

        top = ttk.Frame(pane)
        top.columnconfigure(0, weight=1)
        top.rowconfigure(0, weight=1)
        bottom = ttk.Frame(pane)
        bottom.columnconfigure(0, weight=1)
        bottom.rowconfigure(0, weight=1)
        pane.add(top, weight=1)
        pane.add(bottom, weight=1)

        columns = ("revision_id", "timestamp", "contributor", "comment")
        self.revisions_tree = ttk.Treeview(top, columns=columns, show="headings", selectmode="browse")
        headings = {
            "revision_id": "Revision ID",
            "timestamp": "Edited",
            "contributor": "Contributor",
            "comment": "Comment",
        }
        widths = {
            "revision_id": 110,
            "timestamp": 150,
            "contributor": 150,
            "comment": 320,
        }
        for column in columns:
            self.revisions_tree.heading(column, text=headings[column])
            self.revisions_tree.column(column, width=widths[column], anchor=(tk.W if column in {"contributor", "comment"} else tk.CENTER))
        self.revisions_tree.grid(row=0, column=0, sticky="nsew")
        scroll_y = ttk.Scrollbar(top, orient=tk.VERTICAL, command=self.revisions_tree.yview)
        scroll_y.grid(row=0, column=1, sticky="ns")
        scroll_x = ttk.Scrollbar(top, orient=tk.HORIZONTAL, command=self.revisions_tree.xview)
        scroll_x.grid(row=1, column=0, sticky="ew")
        self.revisions_tree.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        self.revisions_tree.bind("<<TreeviewSelect>>", self._on_revision_selected)

        self.revision_text = self._make_readonly_text(bottom)

    def _build_links_tab(self, parent: ttk.Frame) -> None:
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(1, weight=1)
        ttk.Label(
            parent,
            text="Double-click a link to jump to that page if it exists in the current archive.",
            style="Muted.TLabel",
        ).grid(row=0, column=0, sticky="w", pady=(0, 6))
        frame = ttk.Frame(parent)
        frame.grid(row=1, column=0, sticky="nsew")
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        self.links_listbox = tk.Listbox(frame, exportselection=False)
        self.links_listbox.grid(row=0, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=self.links_listbox.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.links_listbox.configure(yscrollcommand=scrollbar.set)
        self.links_listbox.bind("<Double-1>", self._on_link_double_click)

    def _make_readonly_text(self, parent: ttk.Frame) -> ScrolledText:
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(0, weight=1)
        widget = ScrolledText(parent, wrap=tk.WORD)
        widget.grid(row=0, column=0, sticky="nsew")
        widget.configure(state=tk.DISABLED)
        return widget

    # -----------------------------
    # Helpers and persistence
    # -----------------------------
    def _load_settings(self) -> None:
        geometry = self.state_store.get_setting("window_geometry", "1360x860")
        self.geometry(geometry)
        self.archive_folder_var.set(str(self.state_store.archive_folder()))
        self.project_var.set(self.state_store.get_setting("project_name", "Abstract Wikipedia"))
        self.language_var.set(self.state_store.get_setting("language_code", "en"))
        self.save_format_var.set(self.state_store.get_setting("save_format", SAVE_FORMATS[0]))
        self.dump_choice_var.set(self.state_store.get_setting("dump_choice", DUMP_CHOICES["recommended_reading"]))
        self._update_api_preview()

    def _save_settings(self) -> None:
        self.state_store.set_setting("window_geometry", self.geometry())
        self.state_store.set_setting("archive_folder", self.archive_folder_var.get())
        self.state_store.set_setting("project_name", self.project_var.get())
        self.state_store.set_setting("language_code", self.language_var.get())
        self.state_store.set_setting("save_format", self.save_format_var.get())
        self.state_store.set_setting("dump_choice", self.dump_choice_var.get())
        self.state_store.save()

    def _refresh_download_index(self) -> None:
        self.download_index = self.state_store.download_index()
        self.dump_download_index = self.state_store.dump_download_index()

    def api_projects_fixed_first(self) -> list[str]:
        return list(FIXED_PROJECTS.keys()) + list(LANGUAGE_PROJECTS.keys())

    def _default_bundle_name(self) -> str:
        today = datetime.utcnow().strftime("%Y-%m-%d")
        return f"wiki_bundle_{today}"

    def _thread_safe_log(self, message: str) -> None:
        self.worker_queue.put(("log", message))

    def _set_status(self, message: str) -> None:
        self.status_var.set(message)

    def _log(self, message: str) -> None:
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.activity_text.configure(state=tk.NORMAL)
        self.activity_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.activity_text.see(tk.END)
        self.activity_text.configure(state=tk.DISABLED)

    def _replace_text(self, widget: ScrolledText, text: str) -> None:
        widget.configure(state=tk.NORMAL)
        widget.delete("1.0", tk.END)
        widget.insert(tk.END, text)
        widget.configure(state=tk.DISABLED)

    def _clear_reader(self, headline: str = "No archive loaded.") -> None:
        self.current_bundle = None
        self.current_archive = None
        self.current_page_title = ""
        self.archive_pages_filter_var.set("")
        self.archive_pages_by_iid.clear()
        if hasattr(self, "archive_pages_tree"):
            for item in self.archive_pages_tree.get_children():
                self.archive_pages_tree.delete(item)
        self.archive_pages_status_var.set(headline)
        self.selection_context = None
        self._update_action_buttons()

    def _update_api_preview(self) -> None:
        project_name = self.project_var.get().strip()
        language_code = self.language_var.get().strip()
        self.dump_dbname_var.set("")
        self.dump_summary_var.set("Search & Save Pages is the lighter option. Load archive dates only if you want a whole archive.")
        if hasattr(self, "dump_runs_tree"):
            self.dump_runs_by_iid.clear()
            for item in self.dump_runs_tree.get_children():
                self.dump_runs_tree.delete(item)
        if hasattr(self, "dump_options_tree"):
            self._clear_dump_options()
        if project_name in FIXED_PROJECTS:
            self.language_entry.configure(state=tk.DISABLED)
        else:
            self.language_entry.configure(state=tk.NORMAL)
        try:
            api_url = project_api_url(project_name, language_code)
            self.api_preview_var.set(api_url)
        except WikiArchiveError:
            self.api_preview_var.set("Choose a valid project and language code.")

    def _format_save_extension(self) -> str:
        return ".xml.bz2" if self.save_format_var.get() == SAVE_FORMATS[1] else ".xml"

    def _bundle_by_id(self, entry_id: str) -> Optional[BundleEntry]:
        for bundle in self.state_store.bundle_entries():
            if bundle.entry_id == entry_id:
                return bundle
        return None

    def _current_dump_choice_key(self) -> str:
        selected_label = self.dump_choice_var.get().strip()
        for key, label in DUMP_CHOICES.items():
            if label == selected_label:
                return key
        return "recommended_reading"

    def _selected_dump_run(self) -> Optional[DumpRun]:
        selection = self.dump_runs_tree.selection()
        if not selection:
            return None
        return self.dump_runs_by_iid.get(selection[0])

    def _selected_dump_option(self) -> Optional[DumpOption]:
        selection = self.dump_options_tree.selection()
        if not selection:
            return None
        return self.dump_options_by_iid.get(selection[0])

    def _clear_dump_options(self) -> None:
        self.dump_options_by_iid.clear()
        if hasattr(self, "dump_options_tree"):
            for item in self.dump_options_tree.get_children():
                self.dump_options_tree.delete(item)
        self.dump_confirm_var.set(False)
        if hasattr(self, "dump_review_text"):
            self._set_dump_review("Highlight a whole-archive choice to review it here.")
        self._update_dump_download_state()

    def _set_dump_review(self, message: str) -> None:
        if not hasattr(self, "dump_review_text"):
            return
        self.dump_review_text.configure(state=tk.NORMAL)
        self.dump_review_text.delete("1.0", tk.END)
        self.dump_review_text.insert("1.0", message.strip() or " ")
        self.dump_review_text.configure(state=tk.DISABLED)

    def _render_dump_option_review(self, option: Optional[DumpOption]) -> str:
        if option is None:
            return "Highlight a whole-archive choice to review it here. Nothing downloads until you confirm and click Start whole-archive download."
        run_label = format_dump_run(option.run) if option.run else "latest"
        file_preview = "\n".join(f"• {item.filename}" for item in option.files[:6])
        if len(option.files) > 6:
            file_preview += f"\n• …and {len(option.files) - 6} more file(s)"
        action_summary = (
            "The app will download all listed part files and then build one local archive entry."
            if option.file_count > 1
            else "The app will download one archive file and then build a local page index."
        )
        return (
            f"Selected whole-archive choice: {option.title}\n"
            f"Wiki database: {option.dbname}\n"
            f"Archive date: {run_label}\n"
            f"Recommended: {'Yes' if option.recommended else 'No'}\n"
            f"Scope: {option.scope_label}\n"
            f"Choice type: {option.type_label}\n"
            f"Files to download: {option.file_count}\n"
            f"Total size: {option.total_size_text}\n"
            f"Uploaded: {option.uploaded_at or 'Unknown'}\n"
            f"Already in library: {'Yes' if option.downloaded else 'No'}\n\n"
            f"What will happen:\n- {action_summary}\n- The archive appears in Archive Library after downloading and indexing finish.\n\n"
            f"Files included:\n{file_preview or '• File names are not available.'}\n\n"
            f"Note:\n{option.note or 'This is a whole-archive download.'}"
        )

    def _update_dump_download_state(self) -> None:
        option = self._selected_dump_option() if hasattr(self, "dump_options_tree") else None
        ready = option is not None and self.dump_confirm_var.get()
        if hasattr(self, "dump_download_button"):
            self.dump_download_button.configure(state=(tk.NORMAL if ready else tk.DISABLED))
        if hasattr(self, "dump_confirm_check"):
            self.dump_confirm_check.configure(state=(tk.NORMAL if option is not None else tk.DISABLED))

    def _on_dump_option_selected(self, _event: Any = None) -> None:
        option = self._selected_dump_option()
        self.dump_confirm_var.set(False)
        self._set_dump_review(self._render_dump_option_review(option))
        if option is None:
            self.dump_summary_var.set("Highlight a whole-archive choice to review it before downloading.")
        else:
            self.dump_summary_var.set(
                f"Reviewing '{option.title}'. Nothing will download until you tick the confirmation box and click Start whole-archive download."
            )
        self._update_dump_download_state()

    def _on_dump_choice_changed(self) -> None:
        self.state_store.set_setting("dump_choice", self.dump_choice_var.get())
        current_run = self._selected_dump_run()
        if current_run is None:
            return
        if self.dump_options_by_iid:
            self.load_selected_dump_files()

    def show_walkthrough(self) -> None:
        messagebox.showinfo(
            APP_NAME,
            "Start here\n"
            "1. Search & Save Pages is the lighter path and is the best starting point for most people.\n"
            "2. Download Entire Wiki is only for full wiki archives.\n"
            "3. Select an archive from Archive Library to show its page list on the right.\n"
            "4. Double-click any page row to open it as a local wiki-style webpage.\n\n"
            "Search & Save Pages\n"
            "1. Open Search & Save Pages.\n"
            "2. Search the wiki.\n"
            "3. Double-click a result to open it as a local webpage, or add it to the save list.\n"
            "4. Save the save list as a local archive.\n\n"
            "Download Entire Wiki\n"
            "1. Open Download Entire Wiki.\n"
            "2. Click 1. Load archive dates.\n"
            "3. Highlight a date.\n"
            "4. Click 2. Show whole-archive choices.\n"
            "5. Highlight a choice and review it.\n"
            "6. Tick the confirmation box.\n"
            "7. Click 4. Start whole-archive download.\n\n"
            "Archive browsing\n"
            "1. Double-click an archive in Archive Library, or click Load highlighted archive pages.\n"
            "2. Use the page filter on the right if the archive is large.\n"
            "3. Double-click a page title or namespace row to open it as a local webpage.\n\n"
            "Important: large whole-archive downloads appear in the library after downloading and indexing finish.",
        )

    def load_dump_runs(self) -> None:
        try:
            api_url = project_api_url(self.project_var.get(), self.language_var.get())
        except WikiArchiveError as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return

        def worker() -> tuple[SiteInfo, list[DumpRun]]:
            siteinfo = self.api_client.get_siteinfo(api_url)
            dbname = siteinfo.dbname or ""
            if not dbname:
                raise WikiArchiveError("This wiki does not expose a database name for archive browsing.")
            runs = self.dump_client.list_runs(dbname, downloaded_index=self.dump_download_index)
            return siteinfo, runs

        self._run_worker(
            label="Loading available wiki archive dates",
            worker=worker,
            callback=self._on_dump_runs_loaded,
        )

    def _on_dump_runs_loaded(self, payload: tuple[SiteInfo, list[DumpRun]]) -> None:
        siteinfo, runs = payload
        self.dump_dbname_var.set(siteinfo.dbname or "")
        self.dump_runs_by_iid.clear()
        self._clear_dump_options()
        for item in self.dump_runs_tree.get_children():
            self.dump_runs_tree.delete(item)
        if not runs:
            self.dump_summary_var.set("No archive dates were found for this wiki.")
            return
        selected_iid = ""
        for index, run in enumerate(runs, start=1):
            iid = f"dump_run_{index}"
            self.dump_runs_by_iid[iid] = run
            if run.run != "latest" and not selected_iid:
                selected_iid = iid
            self.dump_runs_tree.insert(
                "",
                tk.END,
                iid=iid,
                values=(
                    run.display_name,
                    run.listed_at,
                    "Yes" if run.downloaded else "No",
                ),
            )
        if not selected_iid:
            selected_iid = next(iter(self.dump_runs_by_iid.keys()), "")
        if selected_iid:
            self.dump_runs_tree.selection_set(selected_iid)
            self.dump_runs_tree.focus(selected_iid)
        dated_count = len([run for run in runs if run.run != "latest"])
        self.dump_summary_var.set(
            f"Loaded {dated_count or len(runs)} archive date entr{'y' if (dated_count or len(runs)) == 1 else 'ies'} for {siteinfo.sitename or siteinfo.dbname}. The latest dated entry is highlighted. Click 2. Show whole-archive choices to continue."
        )
        self._set_dump_review("Highlight a dump date, then click 2. Show whole-archive choices.")
        self.collection_notebook.select(self.full_archive_tab)
        self._log(f"Loaded archive dates for {siteinfo.dbname}.")

    def _on_dump_run_selected(self, _event: Any = None) -> None:
        run = self._selected_dump_run()
        if run is None:
            return
        self._clear_dump_options()
        self.dump_summary_var.set(
            f"Archive date highlighted: {run.display_name}. Click 2. Show whole-archive choices to review what that full archive would download."
        )
        self._set_dump_review("Now click 2. Show whole-archive choices, then highlight one choice to review it here.")

    def load_selected_dump_files(self) -> None:
        run = self._selected_dump_run()
        if run is None:
            messagebox.showerror(APP_NAME, "Highlight an archive date first.")
            return

        def worker() -> tuple[DumpRun, list[DumpOption]]:
            files = self.dump_client.list_files(run.dbname, run.run, downloaded_index=self.dump_download_index)
            options = grouped_dump_options(run.dbname, run.run, files, self._current_dump_choice_key())
            return run, options

        self._run_worker(
            label=f"Loading whole-archive choices for {run.display_name}",
            worker=worker,
            callback=self._on_dump_files_loaded,
        )

    def _on_dump_files_loaded(self, payload: tuple[DumpRun, list[DumpOption]]) -> None:
        run, options = payload
        self._clear_dump_options()
        recommended_iid = ""
        for index, option in enumerate(options, start=1):
            iid = f"dump_option_{index}"
            self.dump_options_by_iid[iid] = option
            if option.recommended and not recommended_iid:
                recommended_iid = iid
            self.dump_options_tree.insert(
                "",
                tk.END,
                iid=iid,
                values=(
                    dump_option_label(option),
                    option.scope_label,
                    option.type_label,
                    option.file_count,
                    option.uploaded_at,
                    option.total_size_text,
                    "Yes" if option.downloaded else "No",
                ),
            )
        if recommended_iid:
            self.dump_options_tree.selection_set(recommended_iid)
            self.dump_options_tree.focus(recommended_iid)
            self.dump_options_tree.see(recommended_iid)
        if options:
            summary = f"Showing {len(options)} whole-archive choice(s) for {run.display_name}. "
            if recommended_iid:
                summary += "The recommended choice is marked with ★. "
            summary += "Nothing has started downloading yet. Review a choice below, tick the confirmation box, then click Start whole-archive download."
        else:
            summary = f"No whole-archive choices were found for {run.display_name}."
        self.dump_summary_var.set(summary)
        self._on_dump_option_selected()
        self.collection_notebook.select(self.full_archive_tab)
        self._log(f"Loaded {len(options)} whole-archive choice(s) for {run.display_name}.")

    def download_recommended_dump(self) -> None:
        options = list(self.dump_options_by_iid.values())
        if not options:
            messagebox.showerror(APP_NAME, "Load the whole-archive choices for the highlighted archive date first.")
            return
        recommended_iid = next((iid for iid, option in self.dump_options_by_iid.items() if option.recommended), None)
        if recommended_iid is None:
            messagebox.showerror(APP_NAME, "No recommended whole-archive choice was found for the current preference.")
            return
        self.dump_options_tree.selection_set(recommended_iid)
        self.dump_options_tree.focus(recommended_iid)
        self.dump_options_tree.see(recommended_iid)
        self._on_dump_option_selected()

    def download_selected_dump_option(self) -> None:
        option = self._selected_dump_option()
        if option is None:
            messagebox.showerror(APP_NAME, "Highlight a whole-archive choice first.")
            return
        if not self.dump_confirm_var.get():
            messagebox.showerror(
                APP_NAME,
                "Tick the confirmation box first. This button downloads a whole wiki archive, not just the selected page.",
            )
            return
        run_label = format_dump_run(option.run) if option.run else "latest"
        confirm_message = (
            "You are about to download a whole wiki archive.\n\n"
            f"Choice: {option.title}\n"
            f"Archive date: {run_label}\n"
            f"Scope: {option.scope_label}\n"
            f"Type: {option.type_label}\n"
            f"Files: {option.file_count}\n"
            f"Total size: {option.total_size_text}\n"
            f"Already in library: {'Yes' if option.downloaded else 'No'}\n\n"
            "This is the whole-archive workflow. It is not the selected-page workflow.\n\n"
            "Start the whole-archive download now?"
        )
        if not messagebox.askyesno(APP_NAME, confirm_message):
            return
        self._download_dump_option(option)

    def _dump_destination_path(self, dump_file: DumpFile) -> Path:
        folder = self.state_store.archive_folder()
        lower_name = dump_file.filename.lower()
        if lower_name.endswith('.xml.bz2'):
            stem = dump_file.filename[:-8]
            ext = '.xml.bz2'
        elif lower_name.endswith('.xml.gz'):
            stem = dump_file.filename[:-7]
            ext = '.xml.gz'
        elif lower_name.endswith('.xml'):
            stem = dump_file.filename[:-4]
            ext = '.xml'
        else:
            return folder / dump_file.filename
        return unique_bundle_name(folder, stem, ext)

    def _unique_archive_folder(self, requested_name: str) -> Path:
        archive_folder = self.state_store.archive_folder()
        candidate = archive_folder / sanitize_filename(requested_name)
        counter = 2
        while candidate.exists():
            candidate = archive_folder / f"{sanitize_filename(requested_name)}_{counter}"
            counter += 1
        return candidate

    def _download_dump_option(self, option: DumpOption) -> None:
        if not option.files:
            messagebox.showerror(APP_NAME, "The selected option does not contain any downloadable archive files.")
            return
        multi_file = len(option.files) > 1
        primary_file = option.files[0]
        destination = self._unique_archive_folder(f"{option.dbname}-{option.run or 'latest'}-{primary_file.family}") if multi_file else self._dump_destination_path(primary_file)

        def worker() -> BundleEntry:
            downloaded_paths: list[Path] = []
            if multi_file:
                destination.mkdir(parents=True, exist_ok=True)
                total_files = len(option.files)
                for index, dump_file in enumerate(option.files, start=1):
                    target_path = destination / dump_file.filename
                    self._thread_safe_log(f"Downloading archive part {index} of {total_files}: {dump_file.filename}")
                    downloaded_path = self.dump_client.download(
                        dump_file.url,
                        target_path,
                        progress=lambda message, i=index, total=total_files: self._thread_safe_log(f"Part {i} of {total} — {message}"),
                    )
                    downloaded_paths.append(downloaded_path)
                self._thread_safe_log("Download complete. Building a combined page index for the full archive…")
                siteinfo, page_index, revision_total = build_archive_index_many(downloaded_paths)
                run_label = format_dump_run(option.run) if option.run else "latest"
                bundle_name = f"{option.dbname} {run_label} {option.scope_label}"
                return build_bundle_entry(
                    path=destination,
                    siteinfo=siteinfo,
                    page_index=page_index,
                    revision_total=revision_total,
                    source_kind="full_dump",
                    managed_copy=True,
                    remote_source_url=primary_file.url,
                    dump_dbname=option.dbname,
                    dump_run=option.run,
                    dump_filename=option.title,
                    source_files=downloaded_paths,
                    dump_filenames=[item.filename for item in option.files],
                    name_override=bundle_name,
                    bundle_type_override="xml-set",
                )
            downloaded_path = self.dump_client.download(primary_file.url, destination, progress=self._thread_safe_log)
            self._thread_safe_log("Download complete. Building a page index for browsing…")
            siteinfo, page_index, revision_total = build_archive_index(downloaded_path)
            return build_bundle_entry(
                path=downloaded_path,
                siteinfo=siteinfo,
                page_index=page_index,
                revision_total=revision_total,
                source_kind="full_dump",
                managed_copy=True,
                remote_source_url=primary_file.url,
                dump_dbname=option.dbname,
                dump_run=option.run,
                dump_filename=primary_file.filename,
                source_files=[downloaded_path],
                dump_filenames=[primary_file.filename],
            )

        label = f"Downloading full archive option: {option.title}"
        self._run_worker(label=label, worker=worker, callback=self._on_dump_downloaded)

    def _on_dump_downloaded(self, bundle: BundleEntry) -> None:
        self.state_store.upsert_bundle(bundle)
        self._refresh_download_index()
        self.refresh_bundle_tree()
        self.bundle_tree.selection_set(bundle.entry_id)
        self.bundle_tree.focus(bundle.entry_id)
        self.selection_context = ("bundle", bundle.entry_id)
        self._log(f"Downloaded full archive '{bundle.name}' into the library.")
        self.open_bundle(bundle)
        current_run = self._selected_dump_run()
        if current_run is not None:
            self.load_selected_dump_files()

    # -----------------------------
    # Worker queue handling
    # -----------------------------
    def _run_worker(
        self,
        *,
        label: str,
        worker: Callable[[], Any],
        callback: Callable[[Any], None],
    ) -> None:
        self._set_status(label)
        self._log(label)
        self.active_tasks += 1
        if hasattr(self, "progressbar") and self.active_tasks == 1:
            self.progressbar.start(10)

        def task() -> None:
            try:
                result = worker()
                self.worker_queue.put(("result", callback, result, label))
            except Exception as exc:  # noqa: BLE001
                self.worker_queue.put(("error", exc, label))

        threading.Thread(target=task, daemon=True).start()

    def _process_worker_queue(self) -> None:
        try:
            while True:
                item = self.worker_queue.get_nowait()
                kind = item[0]
                if kind == "result":
                    _, callback, result, label = item
                    callback(result)
                    self._set_status(f"{label} Finished.")
                    self.active_tasks = max(0, self.active_tasks - 1)
                elif kind == "error":
                    _, exc, label = item
                    message = str(exc) or exc.__class__.__name__
                    self._set_status(f"{label} Failed.")
                    self._log(f"{label} Failed: {message}")
                    self.active_tasks = max(0, self.active_tasks - 1)
                    messagebox.showerror(APP_NAME, f"{label}\n\n{message}")
                elif kind == "log":
                    _, message = item
                    self._log(message)
                if hasattr(self, "progressbar") and self.active_tasks == 0:
                    self.progressbar.stop()
                self.worker_queue.task_done()
        except queue.Empty:
            pass
        self.after(150, self._process_worker_queue)

    # -----------------------------
    # Archive library operations
    # -----------------------------
    def refresh_bundle_tree(self) -> None:
        self._refresh_download_index()
        current_selection = self.bundle_tree.selection()
        current_id = current_selection[0] if current_selection else None
        for item in self.bundle_tree.get_children():
            self.bundle_tree.delete(item)
        bundles = self.state_store.bundle_entries()
        bundles.sort(key=lambda bundle: bundle.added_at, reverse=True)
        for bundle in bundles:
            stored_flag = "Yes" if bundle.managed_copy else "No"
            if not bundle_path_exists(bundle):
                stored_flag = "Missing"
            self.bundle_tree.insert(
                "",
                tk.END,
                iid=bundle.entry_id,
                values=(
                    bundle.name,
                    bundle_kind_label(bundle),
                    bundle.site_name,
                    bundle.page_count,
                    bundle.revision_count,
                    safe_display_date(bundle.added_at),
                    safe_display_date(bundle.last_opened_at),
                    bundle.update_count,
                    stored_flag,
                ),
            )
        if current_id and self.bundle_tree.exists(current_id):
            self.bundle_tree.selection_set(current_id)
        self._update_action_buttons()

    def choose_archive_folder(self) -> None:
        selected = filedialog.askdirectory(initialdir=self.archive_folder_var.get() or str(ARCHIVE_HOME), title="Choose a managed archive folder")
        if not selected:
            return
        self.archive_folder_var.set(selected)
        self.state_store.set_setting("archive_folder", selected)
        self.state_store.save()
        self.refresh_bundle_tree()
        self._log(f"Managed archive folder changed to: {selected}")

    def import_archive_dialog(self, preset_path: Optional[Path] = None) -> None:
        if preset_path is None:
            selected = filedialog.askopenfilename(
                title="Import a MediaWiki XML archive",
                filetypes=[
                    ("MediaWiki XML", "*.xml *.xml.bz2 *.xml.gz"),
                    ("XML only", "*.xml"),
                    ("Compressed XML", "*.xml.bz2 *.xml.gz"),
                ],
            )
            if not selected:
                return
            path = Path(selected)
        else:
            path = Path(preset_path)
        existing = self.state_store.bundle_by_path(str(path.expanduser().resolve()))

        def worker() -> BundleEntry:
            siteinfo, page_index, revision_total = build_archive_index(path)
            return build_bundle_entry(
                path=path,
                siteinfo=siteinfo,
                page_index=page_index,
                revision_total=revision_total,
                source_kind="imported",
                managed_copy=is_managed_copy(path, self.state_store.archive_folder()),
                existing_entry_id=existing.entry_id if existing else None,
                existing_added_at=existing.added_at if existing else None,
            )

        self._run_worker(
            label=f"Importing archive: {path.name}",
            worker=worker,
            callback=self._on_archive_imported,
        )

    def _on_archive_imported(self, bundle: BundleEntry) -> None:
        self.state_store.upsert_bundle(bundle)
        self.refresh_bundle_tree()
        self.bundle_tree.selection_set(bundle.entry_id)
        self.bundle_tree.focus(bundle.entry_id)
        self.selection_context = ("bundle", bundle.entry_id)
        self._update_action_buttons()
        self._log(f"Imported archive '{bundle.name}' with {bundle.page_count} pages.")
        self.open_bundle(bundle)

    def _on_bundle_tree_select(self, _event: Any = None) -> None:
        selection = self.bundle_tree.selection()
        if selection:
            self.selection_context = ("bundle", selection[0])
        self._update_action_buttons()

    def open_selected_archive(self) -> None:
        bundle = self._selected_bundle_entry()
        if bundle is None:
            return
        self.open_bundle(bundle)

    def open_bundle(self, bundle: BundleEntry) -> None:
        if not bundle_path_exists(bundle):
            messagebox.showerror(APP_NAME, "The selected archive file is missing from disk.")
            return
        bundle.last_opened_at = now_utc_iso()
        self.state_store.upsert_bundle(bundle)
        self.refresh_bundle_tree()
        self.current_bundle = bundle
        if bundle.entry_id in self.loaded_archives:
            archive = self.loaded_archives[bundle.entry_id]
            archive.page_index = bundle.pages
        else:
            archive = loaded_archive_from_bundle(bundle)
            self.loaded_archives[bundle.entry_id] = archive
        self.current_archive = archive
        self.archive_pages_filter_var.set("")
        first_title = bundle.pages[0].title if bundle.pages else None
        self.apply_archive_filter(select_title=first_title)
        self._log(f"Loaded archive page list for '{bundle.name}'.")
        self._update_action_buttons()

    def remove_selected_bundle_entry(self) -> None:
        bundle = self._selected_bundle_entry()
        if bundle is None:
            return
        if not messagebox.askyesno(APP_NAME, f"Remove '{bundle.name}' from the library?\n\nThe file itself will not be deleted."):
            return
        self.state_store.remove_bundle(bundle.entry_id)
        self.loaded_archives.pop(bundle.entry_id, None)
        if self.current_bundle and self.current_bundle.entry_id == bundle.entry_id:
            self._clear_reader("The open archive was removed from the library.")
        self.refresh_bundle_tree()
        self._log(f"Removed library entry '{bundle.name}'.")

    def copy_selected_bundle_into_archive(self) -> None:
        bundle = self._selected_bundle_entry()
        if bundle is None:
            return
        if len(bundle_source_paths(bundle)) > 1 or Path(bundle.path).is_dir():
            messagebox.showinfo(APP_NAME, "This full wiki archive is already stored as a managed folder and does not need to be copied as a single file.")
            return
        if is_managed_copy(Path(bundle.path), self.state_store.archive_folder()):
            messagebox.showinfo(APP_NAME, "This archive is already stored inside the managed archive folder.")
            return

        def worker() -> BundleEntry:
            source_path = Path(bundle.path)
            archive_folder = self.state_store.archive_folder()
            destination = archive_folder / source_path.name
            counter = 2
            while destination.exists() and destination.resolve() != source_path.resolve():
                if source_path.name.lower().endswith(".xml.bz2"):
                    stem = source_path.name[:-8]
                    suffix = ".xml.bz2"
                else:
                    stem = source_path.stem
                    suffix = source_path.suffix
                destination = archive_folder / f"{sanitize_filename(stem)}_{counter}{suffix}"
                counter += 1
            if destination.resolve() != source_path.resolve():
                shutil.copy2(source_path, destination)
            siteinfo, page_index, revision_total = build_archive_index(destination)
            return build_bundle_entry(
                path=destination,
                siteinfo=siteinfo,
                page_index=page_index,
                revision_total=revision_total,
                source_kind="imported",
                managed_copy=True,
            )

        self._run_worker(
            label=f"Copying archive into managed folder: {bundle.name}",
            worker=worker,
            callback=self._on_archive_copied,
        )

    def _on_archive_copied(self, new_bundle: BundleEntry) -> None:
        self.state_store.upsert_bundle(new_bundle)
        self.refresh_bundle_tree()
        self.bundle_tree.selection_set(new_bundle.entry_id)
        self.bundle_tree.focus(new_bundle.entry_id)
        self.selection_context = ("bundle", new_bundle.entry_id)
        self._update_action_buttons()
        self._log(f"Created managed archive copy '{new_bundle.name}'.")
        self.open_bundle(new_bundle)

    def open_selected_bundle_location(self) -> None:
        bundle = self._selected_bundle_entry()
        if bundle is None:
            return
        path = Path(bundle.path)
        if not bundle_path_exists(bundle):
            messagebox.showerror(APP_NAME, "The selected archive file is missing from disk.")
            return
        self.open_path_in_system(path if path.is_dir() else path.parent)

    def check_selected_bundle_updates(self) -> None:
        bundle = self._selected_bundle_entry()
        if bundle is None:
            return

        dump_dbname = bundle.dump_dbname or bundle.dbname
        if bundle.source_kind == "full_dump" and dump_dbname:
            def worker() -> tuple[BundleEntry, str]:
                runs = self.dump_client.list_runs(dump_dbname, downloaded_index=self.dump_download_index)
                latest_dated = next((item.run for item in runs if item.run != "latest"), "")
                bundle.last_checked_at = now_utc_iso()
                current_run = bundle.dump_run or ""
                if current_run in {"", "latest"}:
                    bundle.update_count = 0
                else:
                    bundle.update_count = 1 if (latest_dated and latest_dated > current_run) else 0
                return bundle, latest_dated

            self._run_worker(
                label=f"Checking archive dates for: {bundle.name}",
                worker=worker,
                callback=self._on_dump_bundle_updates_checked,
            )
            return

        if not bundle.api_url:
            messagebox.showerror(APP_NAME, "This archive does not have enough site information to check for live wiki updates.")
            return
        if not bundle.pages:
            messagebox.showerror(APP_NAME, "This archive does not contain any pages to check.")
            return

        def worker() -> tuple[BundleEntry, dict[str, str]]:
            updates = self.api_client.check_updates(bundle.api_url, bundle.pages, progress=self._thread_safe_log)
            bundle.last_checked_at = now_utc_iso()
            bundle.update_count = len(updates)
            return bundle, updates

        self._run_worker(
            label=f"Checking wiki updates for: {bundle.name}",
            worker=worker,
            callback=self._on_bundle_updates_checked,
        )

    def _on_dump_bundle_updates_checked(self, payload: tuple[BundleEntry, str]) -> None:
        bundle, latest_dated = payload
        self.state_store.upsert_bundle(bundle)
        self.refresh_bundle_tree()
        current_label = format_dump_run(bundle.dump_run) if bundle.dump_run else "Unknown"
        latest_label = format_dump_run(latest_dated) if latest_dated else "Unknown"
        if bundle.update_count:
            messagebox.showinfo(
                APP_NAME,
                f"A newer archive date is available.\n\nCurrent archive date: {current_label}\nLatest available date: {latest_label}",
            )
            self._log(f"A newer archive date is available for '{bundle.name}': {latest_label}.")
        else:
            messagebox.showinfo(
                APP_NAME,
                f"No newer archive date was found.\n\nCurrent archive date: {current_label}\nLatest available date: {latest_label}",
            )
            self._log(f"No newer archive date was found for '{bundle.name}'.")
        if self.current_bundle and self.current_bundle.entry_id == bundle.entry_id:
            self.current_bundle = bundle
            self.apply_archive_filter(select_title=self.current_page_title)

    def _on_bundle_updates_checked(self, payload: tuple[BundleEntry, dict[str, str]]) -> None:
        bundle, updates = payload
        self.state_store.upsert_bundle(bundle)
        self.refresh_bundle_tree()
        if updates:
            preview = "\n".join(f"• {title} — {safe_local_time(timestamp)}" for title, timestamp in list(updates.items())[:12])
            if len(updates) > 12:
                preview += f"\n…and {len(updates) - 12} more."
            messagebox.showinfo(
                APP_NAME,
                f"Updates were found for {len(updates)} page(s).\n\n{preview}",
            )
            self._log(f"Update check found {len(updates)} changed page(s) for '{bundle.name}'.")
        else:
            messagebox.showinfo(APP_NAME, "No newer wiki edits were found for the pages in this archive.")
            self._log(f"Update check found no changes for '{bundle.name}'.")
        if self.current_bundle and self.current_bundle.entry_id == bundle.entry_id:
            self.current_bundle = bundle
            self.apply_archive_filter(select_title=self.current_page_title)

    # -----------------------------
    # Search and queue operations
    # -----------------------------
    def search_current_wiki(self) -> None:
        search_text = self.search_var.get().strip()
        if not search_text:
            messagebox.showerror(APP_NAME, "Enter something to search for.")
            return
        try:
            api_url = project_api_url(self.project_var.get(), self.language_var.get())
        except WikiArchiveError as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return

        def worker() -> tuple[str, list[SearchResult]]:
            results = self.api_client.search_pages(api_url, search_text)
            return api_url, results

        self._run_worker(
            label=f"Searching wiki for: {search_text}",
            worker=worker,
            callback=self._on_search_results_ready,
        )

    def _on_search_results_ready(self, payload: tuple[str, list[SearchResult]]) -> None:
        api_url, results = payload
        self.search_results_by_iid.clear()
        for item in self.search_tree.get_children():
            self.search_tree.delete(item)

        for index, result in enumerate(results, start=1):
            key = (api_url.strip().lower(), result.title.strip().replace("_", " ").casefold())
            remembered = self.download_index.get(key)
            result.downloaded = remembered is not None
            result.downloaded_at = remembered.get("downloaded_at", "") if remembered else ""
            iid = f"search_{index}"
            self.search_results_by_iid[iid] = result
            self.search_tree.insert(
                "",
                tk.END,
                iid=iid,
                values=(
                    result.title,
                    result.namespace_label,
                    safe_display_date(result.latest_timestamp),
                    "Yes" if result.downloaded else "No",
                    safe_display_date(result.downloaded_at),
                    result.snippet,
                ),
            )
        self.search_summary_var.set(f"Found {len(results)} result(s) on {results[0].site_label if results else self.api_preview_var.get()}. Highlight results and add only what you want to save.")
        self.collection_notebook.select(self.selected_pages_tab)
        self._update_action_buttons()
        self._log(f"Search returned {len(results)} result(s).")

    def clear_search_results(self) -> None:
        self.search_results_by_iid.clear()
        for item in self.search_tree.get_children():
            self.search_tree.delete(item)
        self.search_summary_var.set("Search results cleared.")
        self.selection_context = None
        self._update_action_buttons()

    def _on_search_tree_select(self, _event: Any = None) -> None:
        selection = self.search_tree.selection()
        if selection:
            self.selection_context = ("search", selection[0])
        self._update_action_buttons()

    def add_selected_results_to_queue(self) -> None:
        selected = [self.search_results_by_iid[iid] for iid in self.search_tree.selection() if iid in self.search_results_by_iid]
        if not selected:
            messagebox.showerror(APP_NAME, "Highlight at least one search result first.")
            return
        self._add_items_to_queue(
            [
                QueueItem(
                    title=item.title,
                    namespace=item.namespace,
                    namespace_label=item.namespace_label,
                    page_id=item.page_id,
                    latest_timestamp=item.latest_timestamp,
                    api_url=item.api_url,
                    site_label=item.site_label,
                    downloaded=item.downloaded,
                    downloaded_at=item.downloaded_at,
                )
                for item in selected
            ]
        )

    def add_all_results_to_queue(self) -> None:
        visible_results = [self.search_results_by_iid[iid] for iid in self.search_tree.get_children() if iid in self.search_results_by_iid]
        if not visible_results:
            messagebox.showerror(APP_NAME, "Search the wiki first, then use Add all shown results.")
            return
        self._add_items_to_queue(
            [
                QueueItem(
                    title=item.title,
                    namespace=item.namespace,
                    namespace_label=item.namespace_label,
                    page_id=item.page_id,
                    latest_timestamp=item.latest_timestamp,
                    api_url=item.api_url,
                    site_label=item.site_label,
                    downloaded=item.downloaded,
                    downloaded_at=item.downloaded_at,
                )
                for item in visible_results
            ]
        )

    def expand_selected_results_to_queue(self) -> None:
        selected = [self.search_results_by_iid[iid] for iid in self.search_tree.selection() if iid in self.search_results_by_iid]
        if not selected:
            messagebox.showerror(APP_NAME, "Select at least one search result first.")
            return
        api_url = selected[0].api_url
        if any(item.api_url != api_url for item in selected):
            messagebox.showerror(APP_NAME, "Please expand links from one wiki at a time.")
            return

        def worker() -> list[QueueItem]:
            gathered: list[QueueItem] = []
            seen_titles: set[str] = set()
            for item in selected:
                self._thread_safe_log(f"Loading linked pages from '{item.title}'…")
                links = self.api_client.get_page_links(item.api_url, item.title)
                for link in links:
                    key = link.title.strip().replace("_", " ").casefold()
                    if key in seen_titles:
                        continue
                    seen_titles.add(key)
                    remembered = self.download_index.get((link.api_url.strip().lower(), key))
                    if remembered:
                        link.downloaded = True
                        link.downloaded_at = remembered.get("downloaded_at", "")
                    gathered.append(link)
            return gathered

        self._run_worker(
            label=f"Loading linked pages from {len(selected)} selected result(s)",
            worker=worker,
            callback=self._on_expanded_links_ready,
        )

    def _on_expanded_links_ready(self, items: list[QueueItem]) -> None:
        self._add_items_to_queue(items)
        self._log(f"Added {len(items)} linked page(s) to the queue.")

    def _add_items_to_queue(self, items: list[QueueItem]) -> None:
        if not items:
            messagebox.showinfo(APP_NAME, "There were no new pages to add to the queue.")
            return
        existing = list(self.queue_items_by_iid.values())
        queue_site = existing[0].api_url if existing else None
        if queue_site and any(item.api_url != queue_site for item in items):
            messagebox.showerror(APP_NAME, "The queue can only hold pages from one wiki at a time. Clear the queue before mixing projects.")
            return
        seen = {(item.api_url.strip().lower(), item.title.strip().replace("_", " ").casefold()) for item in existing}
        added_count = 0
        for item in items:
            key = (item.api_url.strip().lower(), item.title.strip().replace("_", " ").casefold())
            if key in seen:
                continue
            iid = f"queue_{len(self.queue_items_by_iid) + 1}_{added_count + 1}"
            self.queue_items_by_iid[iid] = item
            self.queue_tree.insert(
                "",
                tk.END,
                iid=iid,
                values=(
                    item.title,
                    item.namespace_label,
                    item.site_label,
                    safe_display_date(item.latest_timestamp),
                    "Yes" if item.downloaded else "No",
                    safe_display_date(item.downloaded_at),
                ),
            )
            seen.add(key)
            added_count += 1
        if added_count == 0:
            messagebox.showinfo(APP_NAME, "Those pages are already in the queue.")
            return
        first_item = next(iter(self.queue_items_by_iid.values()), None)
        if first_item and self.bundle_name_var.get() == self._default_bundle_name():
            today = datetime.utcnow().strftime("%Y-%m-%d")
            site_name = sanitize_filename(first_item.site_label.lower().replace(" ", "_"))
            self.bundle_name_var.set(f"{site_name}_{today}")
        self.collection_notebook.select(self.selected_pages_tab)
        self._update_queue_summary()
        self._update_action_buttons()
        self._log(f"Added {added_count} page(s) to the queue.")

    def _on_queue_tree_select(self, _event: Any = None) -> None:
        selection = self.queue_tree.selection()
        if selection:
            self.selection_context = ("queue", selection[0])
        self._update_action_buttons()

    def remove_selected_queue_items(self) -> None:
        selection = list(self.queue_tree.selection())
        if not selection:
            messagebox.showerror(APP_NAME, "Select at least one queued page first.")
            return
        for iid in selection:
            self.queue_items_by_iid.pop(iid, None)
            if self.queue_tree.exists(iid):
                self.queue_tree.delete(iid)
        self._update_queue_summary()
        self._update_action_buttons()

    def clear_queue(self) -> None:
        self.queue_items_by_iid.clear()
        for item in self.queue_tree.get_children():
            self.queue_tree.delete(item)
        self._update_queue_summary()
        self._update_action_buttons()

    def _update_queue_summary(self) -> None:
        count = len(self.queue_items_by_iid)
        if count == 0:
            self.queue_summary_var.set("Save list is empty.")
        else:
            site_label = next(iter(self.queue_items_by_iid.values())).site_label
            self.queue_summary_var.set(f"Save list contains {count} page(s) from {site_label}.")

    def download_queue_to_archive(self) -> None:
        items = list(self.queue_items_by_iid.values())
        if not items:
            messagebox.showerror(APP_NAME, "Add some pages to the queue first.")
            return
        if not self.bundle_name_var.get().strip():
            messagebox.showerror(APP_NAME, "Enter a bundle file name first.")
            return
        api_urls = {item.api_url for item in items}
        if len(api_urls) != 1:
            messagebox.showerror(APP_NAME, "The queue can only save pages from one wiki at a time.")
            return

        extension = self._format_save_extension()
        output_path = unique_bundle_name(self.state_store.archive_folder(), self.bundle_name_var.get().strip(), extension)

        def worker() -> tuple[BundleEntry, LoadedArchive]:
            pages: list[PageRecord] = []
            siteinfo: Optional[SiteInfo] = None
            for index, item in enumerate(items, start=1):
                self._thread_safe_log(f"Downloading page {index} of {len(items)}: {item.title}")
                page_siteinfo, page = self.api_client.fetch_full_page_history(item.api_url, item.title)
                if siteinfo is None:
                    siteinfo = page_siteinfo
                pages.append(page)
            if siteinfo is None:
                raise WikiArchiveError("No wiki data was returned for the queue.")
            save_bundle_file(siteinfo, pages, output_path)
            page_index = [
                PageIndexEntry(
                    title=page.title,
                    namespace=page.namespace,
                    page_id=page.page_id,
                    latest_timestamp=page.latest_timestamp,
                    revision_count=len(page.revisions),
                )
                for page in pages
            ]
            bundle = build_bundle_entry(
                path=output_path,
                siteinfo=siteinfo,
                page_index=page_index,
                revision_total=sum(len(page.revisions) for page in pages),
                source_kind="downloaded",
                managed_copy=True,
            )
            archive = loaded_archive_from_bundle(bundle)
            for page in pages:
                archive.pages[page.title] = page
            return bundle, archive

        self._run_worker(
            label=f"Downloading {len(items)} queued page(s) to {output_path.name}",
            worker=worker,
            callback=self._on_queue_downloaded,
        )

    def _on_queue_downloaded(self, payload: tuple[BundleEntry, LoadedArchive]) -> None:
        bundle, archive = payload
        self.state_store.upsert_bundle(bundle)
        self.loaded_archives[bundle.entry_id] = archive
        for page in archive.pages.values():
            save_cached_page(bundle, page)
        self.refresh_bundle_tree()
        self._refresh_download_index()
        self.clear_queue()
        self.bundle_tree.selection_set(bundle.entry_id)
        self.bundle_tree.focus(bundle.entry_id)
        self.selection_context = ("bundle", bundle.entry_id)
        self._log(f"Saved new bundle '{bundle.name}' to {bundle.path}.")
        self.open_bundle(bundle)

    def _materialize_page_for_preview(
        self,
        archive: LoadedArchive,
        bundle: Optional[BundleEntry],
        title: str,
    ) -> Optional[PageRecord]:
        requested_title = title.strip()
        if not requested_title:
            return None
        if requested_title in archive.pages:
            return archive.pages[requested_title]
        if bundle is not None:
            cached = load_cached_page(bundle, requested_title)
            if cached is not None:
                archive.pages[cached.title] = cached
                return cached
            try:
                page = extract_page_from_archive_many(bundle_source_paths(bundle), requested_title)
            except Exception:
                return None
            archive.pages[page.title] = page
            save_cached_page(bundle, page)
            return page
        if archive.siteinfo.api_url:
            try:
                _siteinfo, page = self.api_client.fetch_latest_page(archive.siteinfo.api_url, requested_title)
            except Exception:
                return None
            archive.pages[page.title] = page
            return page
        return None

    def open_current_page_as_webpage(self) -> None:
        if self.current_archive is None or not self.current_page_title:
            messagebox.showerror(APP_NAME, "Open or preview a page first.")
            return
        archive = self.current_archive
        bundle = self.current_bundle
        current_title = self.current_page_title

        def worker() -> Path:
            page = self._materialize_page_for_preview(archive, bundle, current_title)
            if page is None:
                raise WikiArchiveError(f"The page '{current_title}' could not be prepared for webpage view.")
            preview_root_name = bundle.entry_id if bundle else sanitize_filename(archive.siteinfo.dbname or archive.siteinfo.sitename or "live_preview")
            preview_root = PREVIEW_HOME / preview_root_name
            preview_root.mkdir(parents=True, exist_ok=True)

            local_pages: dict[str, PageRecord] = {page.title: page}
            archive_titles = {entry.title for entry in archive.page_index}
            linked_titles = extract_wikilinks(page.latest_revision.text if page.latest_revision else "")
            link_limit = 30 if bundle is not None else 12
            for linked_title in linked_titles[:link_limit]:
                if bundle is not None and archive_titles and linked_title not in archive_titles:
                    continue
                linked_page = self._materialize_page_for_preview(archive, bundle, linked_title)
                if linked_page is not None:
                    local_pages[linked_page.title] = linked_page

            local_hrefs = {title: preview_html_filename(title) for title in local_pages}
            for title, local_page in local_pages.items():
                html_text = build_local_page_html(local_page, archive.siteinfo, local_hrefs=local_hrefs)
                (preview_root / local_hrefs[title]).write_text(html_text, encoding="utf-8")

            current_path = preview_root / local_hrefs[page.title]
            index_path = preview_root / "index.html"
            if current_path != index_path:
                shutil.copy2(current_path, index_path)
            return index_path

        def callback(path: Path) -> None:
            self._log(f"Opened local webpage view for '{current_title}'.")
            self.open_path_in_system(path)

        self._run_worker(
            label=f"Preparing local webpage view for: {current_title}",
            worker=worker,
            callback=callback,
        )

    # -----------------------------
    # Reader operations
    # -----------------------------
    def preview_selected_context(self) -> None:
        self.open_selected_context_as_webpage()

    def open_selected_context_as_webpage(self) -> None:
        if not self.selection_context:
            messagebox.showerror(APP_NAME, "Choose a page or archive first.")
            return

        kind, identifier = self.selection_context
        if kind == "bundle":
            self.open_selected_archive()
            return
        if kind == "archive_page":
            page_entry = self.archive_pages_by_iid.get(identifier)
            if page_entry is None:
                messagebox.showerror(APP_NAME, "Choose a page row on the right first.")
                return
            self.current_page_title = page_entry.title
            self.open_current_page_as_webpage()
            return
        if kind == "search":
            result = self.search_results_by_iid.get(identifier)
            if result is None:
                return
            self._open_live_page_as_webpage(result.api_url, result.title)
            return
        if kind == "queue":
            item = self.queue_items_by_iid.get(identifier)
            if item is None:
                return
            self._open_live_page_as_webpage(item.api_url, item.title)
            return
        messagebox.showerror(APP_NAME, "Choose a page first.")

    def _open_live_page_as_webpage(self, api_url: str, title: str) -> None:
        def worker() -> Path:
            siteinfo, page = self.api_client.fetch_latest_page(api_url, title)
            preview_root = PREVIEW_HOME / f"live_{sanitize_filename(siteinfo.dbname or siteinfo.sitename or 'preview')}"
            preview_root.mkdir(parents=True, exist_ok=True)

            local_pages: dict[str, PageRecord] = {page.title: page}
            linked_titles = extract_wikilinks(page.latest_revision.text if page.latest_revision else "")
            for linked_title in linked_titles[:12]:
                try:
                    _siteinfo, linked_page = self.api_client.fetch_latest_page(api_url, linked_title)
                except Exception:
                    continue
                local_pages[linked_page.title] = linked_page

            local_hrefs = {page_title: preview_html_filename(page_title) for page_title in local_pages}
            for page_title, local_page in local_pages.items():
                html_text = build_local_page_html(local_page, siteinfo, local_hrefs=local_hrefs)
                (preview_root / local_hrefs[page_title]).write_text(html_text, encoding="utf-8")

            current_path = preview_root / local_hrefs[page.title]
            index_path = preview_root / "index.html"
            if current_path != index_path:
                shutil.copy2(current_path, index_path)
            return index_path

        def callback(path: Path) -> None:
            self._log(f"Opened local webpage view for '{title}'.")
            self.open_path_in_system(path)

        self._run_worker(
            label=f"Preparing local webpage view for: {title}",
            worker=worker,
            callback=callback,
        )

    def preview_remote_page(self, api_url: str, title: str) -> None:
        def worker() -> LoadedArchive:
            siteinfo, page = self.api_client.fetch_latest_page(api_url, title)
            page_index = [
                PageIndexEntry(
                    title=page.title,
                    namespace=page.namespace,
                    page_id=page.page_id,
                    latest_timestamp=page.latest_timestamp,
                    revision_count=len(page.revisions),
                )
            ]
            archive = LoadedArchive(
                title=page.title,
                source_label=f"Live preview — {siteinfo.sitename or api_url}",
                source_path="",
                siteinfo=siteinfo,
                page_index=page_index,
                pages={page.title: page},
            )
            return archive

        self._run_worker(
            label=f"Loading live preview: {title}",
            worker=worker,
            callback=self._on_remote_preview_ready,
        )

    def _on_remote_preview_ready(self, archive: LoadedArchive) -> None:
        self.current_bundle = None
        self.current_archive = archive
        self.current_page_title = archive.page_index[0].title if archive.page_index else ""
        self.archive_pages_status_var.set(
            "Live previews now open directly as local webpages. Use Search & Save Pages to add pages to your save list."
        )
        self._log(f"Loaded live preview for '{archive.page_index[0].title if archive.page_index else archive.title}'.")
        self._update_action_buttons()

    def load_selected_page_from_reader(self) -> None:
        # Kept only for backwards compatibility with older builds.
        return

    def _display_page(self, page: PageRecord) -> None:
        # Kept only for backwards compatibility with older builds.
        self.current_page_title = page.title
        if self.current_bundle is not None:
            self.archive_pages_status_var.set(f"{self.current_bundle.name} — page ready: {page.title}")
        elif self.current_archive is not None:
            self.archive_pages_status_var.set(f"{self.current_archive.source_label} — page ready: {page.title}")

    def _on_revision_selected(self, _event: Any = None) -> None:
        return

    def _display_selected_revision_text(self, revision: Any) -> None:
        return

    def _on_link_double_click(self, _event: Any = None) -> None:
        return

    # -----------------------------
    # Selection and system helpers
    # -----------------------------
    def _selected_bundle_entry(self) -> Optional[BundleEntry]:
        selection = self.bundle_tree.selection()
        if not selection:
            return None
        return self._bundle_by_id(selection[0])

    def _update_action_buttons(self) -> None:
        bundle_selected = self._selected_bundle_entry() is not None
        context_kind = self.selection_context[0] if self.selection_context else None
        page_selected = context_kind in {"archive_page", "search", "queue"}
        self.preview_button.configure(state=(tk.NORMAL if page_selected else tk.DISABLED))
        self.open_archive_button.configure(state=(tk.NORMAL if bundle_selected else tk.DISABLED))
        self.check_updates_button.configure(state=(tk.NORMAL if bundle_selected else tk.DISABLED))
        self.archive_copy_button.configure(state=(tk.NORMAL if bundle_selected else tk.DISABLED))
        self.open_location_button.configure(state=(tk.NORMAL if bundle_selected else tk.DISABLED))
        self.remove_bundle_button.configure(state=(tk.NORMAL if bundle_selected else tk.DISABLED))

    def open_path_in_system(self, path: Path) -> None:
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(path))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception:
            webbrowser.open(path.as_uri())

    def on_close(self) -> None:
        self._save_settings()
        self.destroy()


# -----------------------------
# Command line entry points
# -----------------------------

def run_smoke_test(paths: list[Path]) -> int:
    from core import build_archive_index

    for path in paths:
        siteinfo, page_index, revision_total = build_archive_index(path)
        print(f"{path.name}: {siteinfo.sitename or 'Unknown'} — {len(page_index)} pages — {revision_total} revisions")
    return 0


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=APP_NAME)
    parser.add_argument("--open", dest="open_path", type=Path, help="Open an archive file on startup.")
    parser.add_argument("--smoke-test", nargs="*", type=Path, help="Parse one or more archive files without opening the GUI.")
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    args = parse_args(argv or sys.argv[1:])
    if args.smoke_test is not None and len(args.smoke_test) > 0:
        return run_smoke_test(args.smoke_test)
    app = ArchiveReaderApp(open_path=args.open_path)
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
